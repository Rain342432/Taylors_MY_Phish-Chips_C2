# MedQuorum - Scenario S9 (REAL, enforced by TideCloak QEA):
# the IT admin tries to give himself the 'doctor' role. TideCloak parks it as a
# change request; it only takes effect when a SECOND admin approves.
# Run:  powershell -ExecutionPolicy Bypass -File .\demo-qea.ps1

$KC = "http://localhost:8080"; $R = "medquorum"; $PW = "Medquorum1!"
function Tok($u) { (Invoke-RestMethod -Method Post -Uri "$KC/realms/$R/protocol/openid-connect/token" -Body @{ grant_type = "password"; client_id = "admin-cli"; username = $u; password = $PW }).access_token }
function H($t) { @{ Authorization = "Bearer $t" } }
function Roles($u) {
    $p = (Tok $u).Split(".")[1].Replace("-", "+").Replace("_", "/"); while ($p.Length % 4) { $p += "=" }
    ([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($p)) | ConvertFrom-Json).realm_access.roles -join ", "
}
function Say($m, $c = "Cyan") { Write-Host "`n$m" -ForegroundColor $c }

$admin = Tok "admin"
$uid = (Invoke-RestMethod -Uri "$KC/admin/realms/$R/users?username=admin&exact=true" -Headers (H $admin))[0].id
$role = Invoke-RestMethod -Uri "$KC/admin/realms/$R/roles/doctor" -Headers (H $admin)

Say "1) IT admin's roles right now: $(Roles 'admin')"
Say "2) IT admin assigns HIMSELF the 'doctor' role..."
try {
    $resp = Invoke-WebRequest -UseBasicParsing -Method Post -Uri "$KC/admin/realms/$R/users/$uid/role-mappings/realm" -Headers (H $admin) -ContentType "application/json" -Body (ConvertTo-Json @($role) -Compress)
    Write-Host "   TideCloak answered HTTP $($resp.StatusCode) $(if ($resp.StatusCode -eq 202) { '(Accepted = NOT applied, parked as a change request)' })" -ForegroundColor Yellow
} catch { Write-Host "   $($_.Exception.Message)" -ForegroundColor Red }

Start-Sleep 1
$cr = Invoke-RestMethod -Uri "$KC/admin/realms/$R/iga/change-requests?status=PENDING" -Headers (H $admin) | Select-Object -Last 1
if (-not $cr) { Say "No pending change request found - is QEA enabled? (see setup output)" "Red"; exit 1 }
Write-Host "   Pending change request: $($cr.id)"

Say "3) IT admin approves his OWN request..."
try {
    $a = Invoke-RestMethod -Method Post -Uri "$KC/admin/realms/$R/iga/change-requests/$($cr.id)/approve" -Headers (H $admin) -ContentType "application/json" -Body "{}"
    Write-Host "   committed = $($a.committed)   approvals = $($a.authCount)" -ForegroundColor Yellow
} catch { Write-Host "   TideCloak refused: $($_.Exception.Message) $($_.ErrorDetails.Message)" -ForegroundColor Yellow }
Say "   IT admin's roles after his own approval: $(Roles 'admin')" "Yellow"
Write-Host "   -> still no 'doctor': one admin alone cannot change who has access." -ForegroundColor Green

Read-Host "`nPress Enter to let the hospital DIRECTOR approve as the second admin (or Ctrl+C to stop here)"
$d = Invoke-RestMethod -Method Post -Uri "$KC/admin/realms/$R/iga/change-requests/$($cr.id)/approve" -Headers (H (Tok "director")) -ContentType "application/json" -Body "{}"
Write-Host "   committed = $($d.committed)   approvals = $($d.authCount)" -ForegroundColor Yellow
Say "4) IT admin's roles now: $(Roles 'admin')" "Green"
Write-Host "   -> the change took effect only after a quorum of 2 admins. Every proposal and vote is logged by TideCloak." -ForegroundColor Green
Write-Host "   (Clean-up: remove the role again in the admin console, which is also a governed change.)"
