# MedQuorum: emergency records no single party controls

RMIT Hackathon 2026 · Challenge 2 "Build without blind trust" · TideCloak

Paramedics record a patient on scene. The record is encrypted on the device and sealed. After that, **no administrator, no hospital executive and no AI system** can open, alter or delete it alone. Access needs a quorum of independent, Tide-authenticated people, and every attempt is written to a tamper-evident audit trail.

- Full specification: [`docs/SYSTEM_SPEC.md`](docs/SYSTEM_SPEC.md)
- App code: [`app/`](app) (Next.js 16 + `@tidecloak/nextjs`)
- In-app scenario guide: `http://localhost:3000/scenarios`

## Mocked or simulated functionality

| Item | Status |
|---|---|
| Tide login, token verification, realm roles, **QEA quorum on role changes**, **Tide E2EE vault** | **REAL** (local TideCloak) |
| Multi-party access quorum, integrity seals, hash-chained audit, crypto-shred | **APP-LAYER** (real code on TideCloak-verified identities) |
| Key Release Service (case-key escrow) | **SIMULATED** stand-in for Tide threshold encryption + Forseti policy |
| AI triage, route map/ETA, dispatch calls, threat-simulator attacks | **SIMULATED** |

---

## Run instructions (Windows)

### Prerequisites
Windows 10/11 with winget, internet access. The setup script installs **Docker Desktop** and **Node.js LTS** if they're missing.

### 1. Start TideCloak and provision the realm
Open PowerShell in the project folder:
```powershell
powershell -ExecutionPolicy Bypass -File .\setup-tidecloak.ps1
```
The script:
1. Installs Docker Desktop if needed (approve the admin prompt, start Docker Desktop, wait for **Engine running**, then re-run).
2. Installs Node.js if needed (then re-run).
3. Starts `tideorg/tidecloak-dev:latest` on **http://localhost:8080** (master admin `admin` / `password`).
4. Provisions realm **`medquorum`** with roles, the Tide IdP, licence and QEA governance, using the official `init/tcinit.sh` inside a small Alpine container.
5. Prints **ACTION REQUIRED: Open this URL…**. Open it and create the Tide account for the **IT admin** (username `admin`). The script then writes `app/tidecloak.json`.
6. Verifies the app can reach the realm.

### 2. Run the app
```powershell
cd app
npm install
npm run dev
```
Open **http://localhost:3000** and sign in with Tide as `admin`.

### 3. Create the demo accounts (Tide console)
Tide console: `http://localhost:8080/realms/medquorum/tide-console/` (sign in as `admin`).

For each user (`paramedic`, `drlee`, `patient1`, `nok1`, `director`, `compliance`):
1. **People → Add a user** → enter the username → **Add user**.
2. Open the **one-time enrolment link** (use a private window per user) and create that user's Tide account.
3. Assign the realm role (Advanced toggle → **Roles**, or from the user in **People**): `paramedic`→paramedic, `drlee`→doctor, `patient1`→patient, `nok1`→next_of_kin, `director`→hospital_director, `compliance`→compliance_officer, and `admin`→it_admin.
4. Go to **QEA Approvals** → **View** → **Authorize** each change request. While `admin` is the only realm admin, one approval is enough.

**Last**, grant `tide-realm-admin` to `director` and `compliance` and authorize them. With 3 admins the threshold becomes **2**, which is what scenario S9 demonstrates. After a role change, users must sign out and back in to get a fresh token.

### 3b. Fallback if the Tide licence step fails (`TIDE-IDPEXT-VENDOR-KEYGEN_FAILED`)
Tide's licensing service ("Midgard") returned HTTP 500 during the event. TideCloak's **Tideless QEA mode** needs no licence:
```powershell
powershell -ExecutionPolicy Bypass -File .\setup-tideless.ps1
```
This creates realm `medquorum` with QEA governance (2 of 3 admins) and 7 demo users (password `Medquorum1!`), and writes `app/tidecloak.json`. Login is TideCloak password login. Tide-network features (Tide account login, Tide E2EE vault) are unavailable in this mode, and the app says so. `demo-qea.ps1` shows the QEA scenario from the terminal.

### 4. Demo without TideCloak (UI only)
```powershell
cd app
npm run dev:mock
```
A red banner shows mock mode. Personas are one-click, and **no trust guarantees are active**. Use this only to explore the UI.

### Reset demo data
```powershell
cd app
npm run reset-data
```

---

## 2-minute demo script

| Time | Who | What to show |
|---|---|---|
| 0:00 | Narrator | Problem: footage of patients in crisis, controlled by whoever runs the system |
| 0:10 | `paramedic` | Dispatch → route → record → local AI triage → **Encrypt, seal & upload** (point at the ciphertext) |
| 0:35 | `admin` | System console → **Open record as admin** → 403. Raw DB shows ciphertext only |
| 0:45 | `admin` → `director` | **Governance (QEA)** page: ask TideCloak to grant yourself `doctor` → **202, parked**; your own approval = 1 of 2, no role; director approves → committed |
| 1:00 | `drlee` | Case → **Open** → denied → **Next-of-kin proxy** request |
| 1:10 | `nok1` | Approvals → **Approve** |
| 1:20 | `drlee` | Open → video and details decrypt in the browser → **Confirm** AI suggestion (human decides) |
| 1:35 | `director` | **Delete this record** → not executed, parked for compliance + patient |
| 1:45 | `compliance` | Threat simulator: AI bulk-read denied; tamper record → integrity alert; Audit chain |
| 1:55 | `patient1` | Vault encrypted with **Tide E2EE**; "Who touched my records" |

## TideCloak SDK usage (`@tidecloak/nextjs`)
| SDK feature | Where |
|---|---|
| `TideCloakProvider`, `useTideCloak` (login, logout, token, refresh) | `app/lib/client/auth.tsx` |
| `HasRealmRole` role guards | `components/Shell.tsx` → `RoleGate` (paramedic, governance pages) |
| `createTideCloakProxy`: server-side page protection from the SDK's `kcToken` cookie | `app/proxy.ts` |
| `verifyTideCloakToken`: every API call | `app/lib/server/auth.ts` |
| `doEncrypt` / `doDecrypt`: Tide E2EE patient vault | `app/app/patient/page.tsx` |
| TideCloak admin REST with the caller's own token (QEA change requests) | `app/lib/server/kcadmin.ts`, `/governance` |

## Project layout
```
setup-tidecloak.ps1        one-shot Docker + TideCloak + realm setup (Windows)
docs/SYSTEM_SPEC.md        full system specification
app/init/realm.json        realm template: MedQuorum roles + Tide E2EE roles
app/lib/server/            auth (verifyTideCloakToken), policy (quorum), audit (hash chain), krs (key escrow)
app/app/api/               REST API
app/app/*                  pages: paramedic, cases, approvals, patient, admin, audit, scenarios
```
