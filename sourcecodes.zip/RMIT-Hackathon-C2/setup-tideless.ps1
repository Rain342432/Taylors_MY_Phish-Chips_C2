# MedQuorum - FALLBACK setup: TideCloak in "Tideless" QEA mode (no Tide licence needed).
# Use when setup-tidecloak.ps1 fails with TIDE-IDPEXT-VENDOR-KEYGEN_FAILED (Tide licensing service 500).
# Run from this folder:   powershell -ExecutionPolicy Bypass -File .\setup-tideless.ps1

$ErrorActionPreference = "Continue"
Set-Location $PSScriptRoot
$AppDir = Join-Path $PSScriptRoot "app"
function Ok($m) { Write-Host "  [OK] $m" -ForegroundColor Green }
function Warn($m) { Write-Host "  [!!] $m" -ForegroundColor Yellow }

docker info *> $null
if ($LASTEXITCODE -ne 0) { Warn "Start Docker Desktop first."; exit 1 }

$exists = docker ps -a --filter "name=^mytidecloak$" --format "{{.Names}}"
if (-not $exists) {
    docker run --name mytidecloak -d -p 8080:8080 -e KC_BOOTSTRAP_ADMIN_USERNAME=admin -e KC_BOOTSTRAP_ADMIN_PASSWORD=password tideorg/tidecloak-dev:latest
} else { docker start mytidecloak *> $null }

Write-Host "Waiting for TideCloak on http://localhost:8080 ..."
$up = $false
for ($i = 0; $i -lt 60; $i++) {
    try { if ((Invoke-WebRequest -UseBasicParsing -Uri "http://localhost:8080/realms/master" -TimeoutSec 3).StatusCode -eq 200) { $up = $true; break } } catch { }
    Start-Sleep -Seconds 3
}
if (-not $up) { Warn "TideCloak is not answering. Run: docker logs --tail 30 mytidecloak"; exit 1 }
Ok "TideCloak is up"

docker run --rm --network container:mytidecloak -v "${AppDir}:/app" -w /app alpine:3.20 `
    sh -c "apk add --no-cache bash curl jq coreutils >/dev/null && bash init/tideless.sh"
if ($LASTEXITCODE -ne 0) { Warn "Provisioning failed - copy the output above and send it to Claude."; exit 1 }

Ok "app\tidecloak.json written (Tideless mode)"
Write-Host ""
Write-Host "Demo users (password for all: Medquorum1!)" -ForegroundColor Cyan
Write-Host "  admin (it_admin) | director (hospital_director) | compliance (compliance_officer)"
Write-Host "  paramedic | drlee (doctor) | patient1 | nok1 (next_of_kin)"
Write-Host ""
Write-Host "Next:  cd app ; npm install ; npm run dev   ->  http://localhost:3000" -ForegroundColor Green
Write-Host "QEA demo (admin cannot self-grant doctor):  powershell -ExecutionPolicy Bypass -File .\demo-qea.ps1" -ForegroundColor Green
