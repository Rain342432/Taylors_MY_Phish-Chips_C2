// Wipes all prototype data (cases, requests, audit, vaults, escrowed keys).
import fs from 'node:fs'
import path from 'node:path'
const dir = path.join(process.cwd(), 'data')
fs.rmSync(dir, { recursive: true, force: true })
console.log('MedQuorum data reset:', dir)
