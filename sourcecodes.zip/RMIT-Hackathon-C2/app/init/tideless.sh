#!/usr/bin/env bash
# MedQuorum - provision realm 'medquorum' in TideCloak "Tideless" QEA mode.
# Use this when the Tide licence / Cybersecurity Fabric step fails
# (e.g. TIDE-IDPEXT-VENDOR-KEYGEN_FAILED). No Tide network or licence needed.
#   - TideCloak issues + signs tokens (password login)
#   - QEA governance on: role changes become change requests, threshold 2 of the
#     iga-approver admins (admin, director, compliance)
set -uo pipefail
KC="${TIDECLOAK_LOCAL_URL:-http://localhost:8080}"
REALM="medquorum"
CLIENT="medquorum-app"
DIR="$(cd -- "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
OUT="${ADAPTER_OUTPUT_PATH:-${DIR}/../tidecloak.json}"
PW="Medquorum1!"

mtok() { curl -s -X POST "$KC/realms/master/protocol/openid-connect/token" -d username=admin -d password=password -d grant_type=password -d client_id=admin-cli | jq -r .access_token; }
utok() { curl -s -X POST "$KC/realms/$REALM/protocol/openid-connect/token" -d "username=$1" -d "password=$PW" -d grant_type=password -d client_id=admin-cli | jq -r '.access_token // empty'; }

T=$(mtok)
[[ -z "$T" || "$T" == "null" ]] && { echo "ERROR: cannot get master admin token (is TideCloak up? admin/password?)"; exit 1; }

echo "1. Removing any existing '$REALM' realm (half-provisioned from earlier attempts)..."
curl -s -o /dev/null -w "   delete -> %{http_code}\n" -X DELETE "$KC/admin/realms/$REALM" -H "Authorization: Bearer $T"

echo "2. Importing realm (roles, client, 7 demo users)..."
code=$(curl -s -o /tmp/r.txt -w "%{http_code}" -X POST "$KC/admin/realms" -H "Authorization: Bearer $T" -H "Content-Type: application/json" --data-binary @"$DIR/realm-tideless.json")
echo "   realm import -> $code"; [[ "$code" != 201 ]] && { cat /tmp/r.txt; exit 1; }

echo "3. Enabling QEA governance (simple attestor, no Tide crypto)..."
T=$(mtok)
code=$(curl -s -o /tmp/r.txt -w "%{http_code}" -X POST "$KC/admin/realms/$REALM/tide-admin/toggle-iga" -H "Authorization: Bearer $T" -H "Content-Type: application/json" -d '{"enabled":true}')
echo "   toggle-iga -> $code $(head -c 200 /tmp/r.txt)"
QEA=1; [[ "$code" != 2* && "$code" != 409 ]] && { QEA=0; echo "   WARNING: QEA could not be enabled - the app will still work, scenario S9 will not."; }

if [[ $QEA == 1 ]]; then
  echo "4. Approving the bootstrap (ADOPT) change requests with two admins..."
  for who in master admin director compliance; do
    if [[ $who == master ]]; then TK=$(mtok); else TK=$(utok "$who"); fi
    [[ -z "$TK" ]] && { echo "   ($who: no token)"; continue; }
    ids=$(curl -s "$KC/admin/realms/$REALM/iga/change-requests?status=PENDING" -H "Authorization: Bearer $TK" | jq -r '.[]?.id // empty' 2>/dev/null)
    n=0; for id in $ids; do curl -s -o /dev/null -X POST "$KC/admin/realms/$REALM/iga/change-requests/$id/approve" -H "Authorization: Bearer $TK" -H "Content-Type: application/json" -d '{}'; n=$((n+1)); done
    echo "   $who approved $n pending request(s)"
  done
  left=$(curl -s "$KC/admin/realms/$REALM/iga/change-requests?status=PENDING" -H "Authorization: Bearer $(mtok)" | jq 'length' 2>/dev/null)
  echo "   still pending: ${left:-?}"
fi

echo "5. Writing adapter config -> $OUT"
T=$(mtok)
CID=$(curl -s "$KC/admin/realms/$REALM/clients?clientId=$CLIENT" -H "Authorization: Bearer $T" | jq -r '.[0].id')
curl -s "$KC/admin/realms/$REALM/clients/$CID/installation/providers/keycloak-oidc-keycloak-json" -H "Authorization: Bearer $T" \
  | jq '. + {"setupRequestEnclave": false, "tokenSignatureAlgorithms": ["RS256","ES256","ES384","ES512","EdDSA"], "medquorumMode": "tideless"}' > "$OUT.tmp"
if jq -e '.realm' "$OUT.tmp" >/dev/null 2>&1; then cat "$OUT.tmp" > "$OUT"; rm -f "$OUT.tmp"; else echo "ERROR: adapter fetch failed"; cat "$OUT.tmp"; exit 1; fi
cat "$OUT"

echo "6. Smoke test: log in as drlee and check the token carries the doctor role..."
TK=$(utok drlee)
if [[ -n "$TK" ]]; then
  echo "$TK" | cut -d. -f2 | tr '_-' '/+' | base64 -d 2>/dev/null | jq -c '{user:.preferred_username, roles:.realm_access.roles, alg:"see header"}' 2>/dev/null || echo "   token ok"
else
  echo "   (direct password grant disabled for admin-cli in this realm - fine, browser login will be used)"
fi
echo ""
echo "DONE. Realm '$REALM' ready (Tideless QEA mode = $QEA). Demo password for all 7 users: $PW"
