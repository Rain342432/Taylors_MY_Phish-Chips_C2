'use client'
import Link from 'next/link'

const MODE_LABEL: Record<string, string> = {
  consent: 'Patient consent',
  proxy: 'Next-of-kin proxy',
  breakglass: 'BREAK-GLASS',
  deletion: 'Deletion request',
}

export default function RequestCard({ r, onApprove, onDeny, showCase = true }: { r: any; onApprove?: (slot: number) => void; onDeny?: () => void; showCase?: boolean }) {
  const filled = r.slots.filter((s: any) => s.approvedBy).length
  const statusBadge =
    r.status === 'approved' ? 'b-ok' : r.status === 'executed' ? 'b-bad' : r.status === 'pending' ? 'b-warn' : 'b-role'
  return (
    <div className="card soft" style={{ marginBottom: 10 }}>
      <div className="spread">
        <div>
          <strong>{MODE_LABEL[r.mode] || r.mode}</strong> <span className="muted small">{r.id}</span>
          {showCase && <> · <Link href={`/cases/${r.caseId}`}>{r.caseId}</Link></>}
        </div>
        <span className={`badge ${statusBadge}`}>{r.status.toUpperCase()} {r.status === 'pending' && `${filled}/${r.slots.length}`}</span>
      </div>
      <div className="small muted" style={{ margin: '4px 0' }}>Requested by <strong>{r.requester}</strong> · {new Date(r.createdAt).toLocaleString()} {r.reason && <>· &quot;{r.reason}&quot;</>}</div>
      <div className="slot done"><span className="small">{r.kind === 'access' ? 'Treating doctor (requester)' : 'Proposer'}: <strong>{r.requester}</strong></span><span className="badge b-ok">initiated</span></div>
      {r.slots.map((s: any, i: number) => (
        <div key={i} className={`slot ${s.approvedBy ? 'done' : ''}`}>
          <span className="small">{s.label}{s.user ? ` · must be ${s.user}` : ` · any ${s.role}`}</span>
          {s.approvedBy ? (
            <span className="badge b-ok">approved by {s.approvedBy}</span>
          ) : r.fillable?.includes(i) && onApprove ? (
            <button className="ok small" onClick={() => onApprove(i)}>Approve as {s.label.split(' (')[0]}</button>
          ) : (
            <span className="badge b-role">waiting</span>
          )}
        </div>
      ))}
      {r.status === 'pending' && r.fillable?.length > 0 && onDeny && <button className="danger small" style={{ marginTop: 6 }} onClick={onDeny}>Refuse</button>}
      {r.grantExpiresAt && <div className="small" style={{ marginTop: 6 }}>Access window ends {new Date(r.grantExpiresAt).toLocaleTimeString()}</div>}
      {r.deniedBy && <div className="small" style={{ marginTop: 6, color: 'var(--bad)' }}>Refused by {r.deniedBy}</div>}
    </div>
  )
}
