'use client'
// SIMULATED route map. Deliberately uses no external map API, so the patient's
// address is never sent to a third party just to draw a route.
export default function RouteMap({ seed = 1 }: { seed?: number }) {
  const pts = seed === 1
    ? [[40, 250], [40, 170], [150, 170], [150, 90], [290, 90], [290, 40], [360, 40]]
    : [[40, 250], [120, 250], [120, 140], [240, 140], [240, 200], [360, 200]]
  const d = pts.map((p, i) => `${i ? 'L' : 'M'}${p[0]},${p[1]}`).join(' ')
  const end = pts[pts.length - 1]
  const km = seed === 1 ? 4.2 : 3.1
  return (
    <div>
      <svg viewBox="0 0 400 290" style={{ width: '100%', background: '#0a1426', borderRadius: 8, border: '1px solid var(--line)' }} role="img" aria-label="Simulated route map">
        {Array.from({ length: 9 }).map((_, i) => <line key={'h' + i} x1="0" x2="400" y1={i * 35 + 5} y2={i * 35 + 5} stroke="#15223d" strokeWidth="6" />)}
        {Array.from({ length: 12 }).map((_, i) => <line key={'v' + i} y1="0" y2="290" x1={i * 37 + 3} x2={i * 37 + 3} stroke="#15223d" strokeWidth="6" />)}
        <path d={d} fill="none" stroke="#3fa7ff" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="10 8">
          <animate attributeName="stroke-dashoffset" from="36" to="0" dur="0.8s" repeatCount="indefinite" />
        </path>
        <circle cx={pts[0][0]} cy={pts[0][1]} r="9" fill="#2ecc8f" />
        <text x={pts[0][0] + 12} y={pts[0][1] + 4} fill="#cfe" fontSize="11">Ambulance</text>
        <circle cx={end[0]} cy={end[1]} r="9" fill="#ff5d6c" />
        <text x={end[0] - 46} y={end[1] + 24} fill="#fcc" fontSize="11">Patient</text>
      </svg>
      <div className="spread small" style={{ marginTop: 6 }}>
        <span>Fastest route: <strong>{km} km</strong> · ETA <strong>{Math.round(km * 1.9)} min</strong> (lights &amp; siren)</span>
        <span className="badge b-sim">SIMULATED ROUTE</span>
      </div>
    </div>
  )
}
