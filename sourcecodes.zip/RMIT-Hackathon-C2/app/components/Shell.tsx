'use client'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { useEffect, type ReactNode } from 'react'
import { HasRealmRole } from '@tidecloak/nextjs'
import { useAuth, MOCK, CONFIGURED, TIDELESS } from '@/lib/client/auth'

const APP_ROLES = ['paramedic', 'doctor', 'patient', 'next_of_kin', 'compliance_officer', 'hospital_director', 'it_admin']

export function appRoles(roles: string[]) {
  return roles.filter((r) => APP_ROLES.includes(r))
}

export default function Shell({ children, requireAuth = true }: { children: ReactNode; requireAuth?: boolean }) {
  const auth = useAuth()
  const path = usePathname()
  const router = useRouter()
  useEffect(() => {
    if (requireAuth && auth.ready && !auth.authenticated) router.push('/')
  }, [requireAuth, auth.ready, auth.authenticated, router])

  const r = auth.roles
  const links: [string, string, boolean][] = [
    ['/home', 'Dashboard', true],
    ['/paramedic', 'Dispatch & capture', r.includes('paramedic')],
    ['/cases', 'Case records', ['doctor', 'compliance_officer', 'hospital_director', 'it_admin', 'paramedic'].some((x) => r.includes(x))],
    ['/approvals', 'Approvals', true],
    ['/patient', 'My records & vault', true],
    ['/admin', 'System console', r.includes('it_admin') || r.includes('compliance_officer')],
    ['/governance', 'Governance (QEA)', ['it_admin', 'hospital_director', 'compliance_officer'].some((x) => r.includes(x))],
    ['/audit', 'Audit trail', true],
    ['/scenarios', 'Scenarios', true],
  ]

  return (
    <>
      {MOCK ? (
        <div className="banner mock">MOCK AUTH MODE: no TideCloak. UI testing only. Trust guarantees are NOT active.</div>
      ) : CONFIGURED && TIDELESS ? (
        <div className="banner tide">Secured by TideCloak (Tideless QEA mode): signed tokens + quorum-governed roles. Tide Fabric features (Tide login, E2EE) unavailable: licence service failed</div>
      ) : CONFIGURED ? (
        <div className="banner tide">Secured by TideCloak: Tide login, quorum-governed roles, Tide E2EE</div>
      ) : (
        <div className="banner mock">TideCloak is not configured yet. Run setup-tidecloak.ps1 to create app/tidecloak.json</div>
      )}
      <div className="topbar">
        <div className="inner">
          <Link href={auth.authenticated ? '/home' : '/'} className="brand">Med<span>Quorum</span></Link>
          {auth.authenticated && (
            <nav className="nav">
              {links.filter((l) => l[2]).map(([href, label]) => (
                <Link key={href} href={href} className={path?.startsWith(href) ? 'active' : ''}>{label}</Link>
              ))}
            </nav>
          )}
          {auth.authenticated && (
            <div className="who">
              <strong style={{ color: 'var(--text)' }}>{auth.username}</strong>
              {appRoles(r).map((x) => <span key={x} className="badge b-role">{x}</span>)}
              {appRoles(r).length === 0 && <span className="badge b-warn">no app role yet</span>}
              <button className="small" onClick={() => auth.logout()}>Sign out</button>
            </div>
          )}
        </div>
      </div>
      <main className="wrap">{children}</main>
    </>
  )
}

export function Tag({ kind }: { kind: 'real' | 'app' | 'sim' }) {
  if (kind === 'real') return <span className="badge b-real" title="Enforced by TideCloak / Tide Fabric">REAL · TideCloak</span>
  if (kind === 'app') return <span className="badge b-app" title="Enforced by MedQuorum server using TideCloak-verified identities">APP-LAYER</span>
  return <span className="badge b-sim" title="Simulated / mocked for the prototype">SIMULATED</span>
}

export function Msg({ m }: { m: { kind: 'ok' | 'bad' | 'info'; text: string } | null }) {
  if (!m) return null
  return <div className={`msg ${m.kind}`}>{m.text}</div>
}

// Role-gated rendering. In TideCloak mode this is the SDK's own <HasRealmRole>
// guard (reads the signed token); in mock mode it falls back to the mock roles.
// UI gating is convenience only - every API call is re-verified on the server.
export function RoleGate({ roles, children, fallback = null }: { roles: string[]; children: ReactNode; fallback?: ReactNode }) {
  const auth = useAuth()
  if (auth.mode === 'tide' && CONFIGURED && !MOCK) {
    return roles.reduceRight<ReactNode>((inner, role) => <HasRealmRole role={role} fallback={inner}>{children}</HasRealmRole>, fallback)
  }
  return <>{roles.some((r) => auth.roles.includes(r)) ? children : fallback}</>
}
