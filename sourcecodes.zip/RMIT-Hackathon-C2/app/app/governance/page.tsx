'use client'
import { useCallback, useEffect, useState } from 'react'
import Shell, { Tag, Msg, RoleGate } from '@/components/Shell'
import { useAuth, api, TIDELESS, MOCK } from '@/lib/client/auth'
import tcConfig from '../../tidecloak.json'

const TIDE_CONSOLE = `${String((tcConfig as any)['auth-server-url'] || 'http://localhost:8080').replace(/\/$/, '')}/realms/${(tcConfig as any).realm || 'medquorum'}/tide-console/`

export default function Governance() {
  const auth = useAuth()
  const [d, setD] = useState<any>(null)
  const [userId, setUserId] = useState('')
  const [role, setRole] = useState('doctor')
  const [msg, setMsg] = useState<{ kind: 'ok' | 'bad' | 'info'; text: string } | null>(null)

  const load = useCallback(async () => {
    const r = await api(auth, '/api/governance')
    if (r.ok) {
      setD(r.data)
      if (!userId && r.data.users.length) setUserId((r.data.users.find((x: any) => x.username === auth.username) || r.data.users[0]).id)
    } else setMsg({ kind: 'bad', text: r.data?.error || `HTTP ${r.status}` })
  }, [auth, userId])
  useEffect(() => { if (auth.authenticated) load() }, [auth.authenticated]) // eslint-disable-line

  async function assign() {
    const target = d?.users.find((x: any) => x.id === userId)
    const r = await api(auth, '/api/governance/assign', { method: 'POST', body: JSON.stringify({ userId, username: target?.username, role }) })
    const s = r.data?.status ?? r.status
    setMsg(s === 202
      ? { kind: 'info', text: `TideCloak answered 202 Accepted: the grant of '${role}' to ${target?.username} was NOT applied. It is parked as a change request below and needs the admin quorum.` }
      : s < 300 ? { kind: 'ok', text: `TideCloak applied it immediately (HTTP ${s}): QEA is not enforcing on this realm.` }
        : { kind: 'bad', text: `TideCloak refused (HTTP ${s}): ${JSON.stringify(r.data?.body || r.data?.error)}` })
    load()
  }

  async function approve(id: string) {
    const r = await api(auth, '/api/governance/approve', { method: 'POST', body: JSON.stringify({ id }) })
    const b = r.data?.body
    setMsg(r.ok
      ? { kind: b?.committed ? 'ok' : 'info', text: b?.committed ? 'Quorum reached: TideCloak committed the change. The user gets the role at their next sign-in.' : `Approval recorded (${b?.authCount ?? '?'} so far). Still below the threshold, so nothing has changed yet.` }
      : { kind: 'bad', text: `TideCloak refused (HTTP ${r.data?.status || r.status}): ${typeof b === 'string' ? b : JSON.stringify(b || r.data?.error)}` })
    load()
  }

  return (
    <Shell>
      <div className="section spread"><h1>Governance (TideCloak QEA)</h1><Tag kind="real" /></div>
      <p className="muted">Who is a doctor, compliance officer or admin is decided <strong>in TideCloak</strong>, not in MedQuorum. With Quorum-Enforced Authorization, a role grant is never applied by one admin: TideCloak parks it until max(1, ⌊0.7 × admins⌋) distinct admins approve. This page talks to TideCloak with <em>your own</em> token; MedQuorum holds no admin credentials.</p>
      {MOCK && <div className="msg bad">Governance needs a real TideCloak realm. It is not available in mock mode.</div>}
      <Msg m={msg} />
      <RoleGate roles={['it_admin', 'hospital_director', 'compliance_officer']} fallback={<div className="card section">Admins only.</div>}>
        <div className="grid g2 section">
          <div className="card">
            <h2>Request a role change</h2>
            <p className="small muted">Try it as <strong>admin</strong>: give yourself <code>doctor</code>. TideCloak should answer 202 and park it.</p>
            <label>User</label>
            <select value={userId} onChange={(e) => setUserId(e.target.value)}>
              {(d?.users || []).map((x: any) => <option key={x.id} value={x.id}>{x.username} {x.roles.length ? `(${x.roles.join(', ')})` : ''}</option>)}
            </select>
            <label>Realm role to grant</label>
            <select value={role} onChange={(e) => setRole(e.target.value)}>
              {(d?.appRoles || []).map((r: string) => <option key={r}>{r}</option>)}
            </select>
            <button className="primary" style={{ marginTop: 10 }} onClick={assign} disabled={!userId}>Ask TideCloak to grant</button>
          </div>
          <div className="card">
            <div className="spread"><h2>Pending change requests</h2><button className="small" onClick={load}>Refresh</button></div>
            {d && d.pendingStatus !== 200 && <div className="msg bad">TideCloak returned HTTP {d.pendingStatus} for the change-request list: {JSON.stringify(d.pendingError)}</div>}
            {(d?.pending || []).length === 0 && <p className="muted small">No pending requests.</p>}
            {(d?.pending || []).map((c: any) => (
              <div key={c.id} className="slot">
                <div className="small">
                  <div><strong>{c.actionType || c.action || c.type || 'change'}</strong> {c.targetName || c.target || c.resourceName || ''}</div>
                  <div className="muted mono">{c.id}</div>
                  <div className="muted">approvals: {c.authCount ?? c.approvals?.length ?? '?'} · {c.status || 'PENDING'}</div>
                </div>
                {TIDELESS
                  ? <button className="ok small" onClick={() => approve(c.id)}>Approve as {auth.username}</button>
                  : <a className="btn small" href={TIDE_CONSOLE} target="_blank" rel="noreferrer">Authorize in Tide enclave</a>}
              </div>
            ))}
            {!TIDELESS && <p className="small muted" style={{ marginTop: 8 }}>On a Tide-licensed realm, each admin authorizes in the Tide enclave (threshold-signed by the Tide Fabric), via the Tide console → QEA Approvals.</p>}
          </div>
        </div>
        <div className="card section">
          <h2>Current app roles (from TideCloak)</h2>
          <table>
            <thead><tr><th>User</th><th>Realm roles</th></tr></thead>
            <tbody>{(d?.users || []).map((x: any) => <tr key={x.id}><td>{x.username}</td><td>{x.roles.join(', ') || <span className="muted">none</span>}</td></tr>)}</tbody>
          </table>
        </div>
      </RoleGate>
    </Shell>
  )
}
