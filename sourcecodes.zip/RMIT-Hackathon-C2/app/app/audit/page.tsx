'use client'
import { useCallback, useEffect, useState } from 'react'
import Shell from '@/components/Shell'
import { useAuth, api } from '@/lib/client/auth'

export default function Audit() {
  const auth = useAuth()
  const [d, setD] = useState<any>(null)
  const load = useCallback(async () => {
    const r = await api(auth, '/api/audit')
    if (r.ok) setD(r.data)
  }, [auth])
  useEffect(() => { if (auth.authenticated) load() }, [auth.authenticated, load])

  return (
    <Shell>
      <div className="section spread">
        <h1>Audit trail</h1>
        <div className="row">
          {d && (d.integrity.ok
            ? <span className="badge b-ok">CHAIN VALID · {d.integrity.entries} entries · head {String(d.integrity.head).slice(0, 12)}…</span>
            : <span className="badge b-bad">CHAIN BROKEN at entry #{d.integrity.brokenAt}: {d.integrity.reason}</span>)}
          <button className="small" onClick={load}>Re-verify</button>
        </div>
      </div>
      <p className="muted">Every entry stores the SHA-256 of the previous one. Editing or deleting any past entry, even directly in the database, breaks the chain from that point. Scope: <strong>{d?.scope === 'full' ? 'full log (oversight role)' : 'your actions and your records'}</strong>.</p>
      <div className="card">
        <table>
          <thead><tr><th>#</th><th>When</th><th>Actor</th><th>Action</th><th>Result</th><th>Case</th><th>Detail</th><th>Hash</th></tr></thead>
          <tbody>
            {(d?.entries || []).map((e: any) => (
              <tr key={e.seq} style={!d.integrity.ok && e.seq === d.integrity.brokenAt ? { background: 'rgba(255,93,108,.12)' } : undefined}>
                <td>{e.seq}</td>
                <td className="small">{new Date(e.ts).toLocaleTimeString()}</td>
                <td>{e.actor}<div className="small muted">{e.actorRoles.join(', ')}</div></td>
                <td className="small">{e.action}</td>
                <td><span className={`badge ${e.outcome === 'OK' ? 'b-ok' : e.outcome === 'PENDING' ? 'b-warn' : 'b-bad'}`}>{e.outcome}</span></td>
                <td className="small">{e.caseId || ''}</td>
                <td className="small">{e.detail}</td>
                <td className="mono small muted">{e.hash.slice(0, 10)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Shell>
  )
}
