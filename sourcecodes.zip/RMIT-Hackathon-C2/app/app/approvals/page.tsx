'use client'
import { useCallback, useEffect, useState } from 'react'
import Shell, { Tag, Msg } from '@/components/Shell'
import RequestCard from '@/components/RequestCard'
import { useAuth, api } from '@/lib/client/auth'

export default function Approvals() {
  const auth = useAuth()
  const [list, setList] = useState<any[]>([])
  const [msg, setMsg] = useState<{ kind: 'ok' | 'bad' | 'info'; text: string } | null>(null)
  const load = useCallback(async () => {
    const r = await api(auth, '/api/requests')
    if (r.ok) setList(r.data.requests)
  }, [auth])
  useEffect(() => { if (auth.authenticated) load() }, [auth.authenticated, load])

  async function approve(id: string, slot: number) {
    const r = await api(auth, `/api/requests/${id}/approve`, { method: 'POST', body: JSON.stringify({ slot }) })
    setMsg(r.ok ? { kind: 'ok', text: r.data.request.status === 'pending' ? 'Your approval is recorded. Still waiting for the others.' : `Quorum complete: request ${r.data.request.status}.` } : { kind: 'bad', text: r.data?.error })
    load()
  }
  async function deny(id: string) {
    const r = await api(auth, `/api/requests/${id}/deny`, { method: 'POST' })
    setMsg(r.ok ? { kind: 'ok', text: 'Refused. The requester gets nothing.' } : { kind: 'bad', text: r.data?.error })
    load()
  }

  const actionable = list.filter((r) => r.fillable?.length)
  const other = list.filter((r) => !r.fillable?.length)
  return (
    <Shell>
      <div className="section spread"><h1>Approvals</h1><Tag kind="app" /></div>
      <p className="muted">Each request needs every slot filled by a <em>different</em> TideCloak-verified person. The server rejects self-approval, double approval, wrong role and wrong person. Any eligible approver can refuse.</p>
      <Msg m={msg} />
      <div className="section">
        <h2>Waiting for you ({actionable.length})</h2>
        {actionable.length === 0 && <p className="muted">Nothing needs your approval right now.</p>}
        {actionable.map((r) => <RequestCard key={r.id} r={r} onApprove={(s) => approve(r.id, s)} onDeny={() => deny(r.id)} />)}
      </div>
      <div className="section">
        <h2>Other requests you can see</h2>
        {other.map((r) => <RequestCard key={r.id} r={r} />)}
        {other.length === 0 && <p className="muted">None.</p>}
      </div>
    </Shell>
  )
}
