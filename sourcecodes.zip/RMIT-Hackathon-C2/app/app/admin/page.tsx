'use client'
import { useCallback, useEffect, useState } from 'react'
import Link from 'next/link'
import Shell, { Tag, Msg } from '@/components/Shell'
import { useAuth, api } from '@/lib/client/auth'
import tcConfig from '../../tidecloak.json'

const TIDE_CONSOLE = `${String((tcConfig as any)['auth-server-url'] || 'http://localhost:8080').replace(/\/$/, '')}/realms/${(tcConfig as any).realm || 'medquorum'}/tide-console/`

export default function Admin() {
  const auth = useAuth()
  const [d, setD] = useState<any>(null)
  const [caseId, setCaseId] = useState('')
  const [msg, setMsg] = useState<{ kind: 'ok' | 'bad' | 'info'; text: string } | null>(null)
  const load = useCallback(async () => {
    const r = await api(auth, '/api/admin/inspect')
    if (r.ok) { setD(r.data); if (!caseId && r.data.cases[0]) setCaseId((r.data.cases.find((c: any) => c.status === 'sealed') || r.data.cases[0]).id) }
    else setMsg({ kind: 'bad', text: r.data?.error })
  }, [auth, caseId])
  useEffect(() => { if (auth.authenticated) load() }, [auth.authenticated]) // eslint-disable-line

  async function sim(kind: string) {
    const r = await api(auth, '/api/simulate', { method: 'POST', body: JSON.stringify({ kind, caseId }) })
    setMsg(r.ok ? { kind: 'info', text: r.data.result } : { kind: 'bad', text: r.data?.error })
    load()
  }
  async function tryOpen() {
    const r = await api(auth, `/api/cases/${caseId}/key`)
    setMsg(r.ok ? { kind: 'ok', text: 'Key released (you must be a doctor with an approved quorum).' } : { kind: 'bad', text: `${r.status} DENIED · ${r.data?.error}` })
  }
  async function trySelfGrant() {
    const r = await api(auth, `/api/cases/${caseId}/requests`, { method: 'POST', body: JSON.stringify({ mode: 'breakglass', reason: 'admin wants to look' }) })
    setMsg(r.ok ? { kind: 'info', text: 'Request created (you must hold the doctor role).' } : { kind: 'bad', text: `${r.status} DENIED · ${r.data?.error}` })
  }

  return (
    <Shell>
      <div className="section spread"><h1>System console</h1><span className="muted small">IT administrator / compliance</span></div>
      <Msg m={msg} />

      <div className="grid g2 section">
        <div className="card">
          <div className="spread"><h2>Admin tries to read a patient record</h2><Tag kind="app" /></div>
          <label>Target case</label>
          <select value={caseId} onChange={(e) => setCaseId(e.target.value)}>
            {(d?.cases || []).map((c: any) => <option key={c.id} value={c.id}>{c.id} · {c.patientUsername}</option>)}
          </select>
          <div className="row" style={{ marginTop: 10 }}>
            <button className="danger" onClick={tryOpen} disabled={!caseId}>Open record as admin</button>
            <button className="danger" onClick={trySelfGrant} disabled={!caseId}>Self-grant break-glass</button>
          </div>
          <p className="small muted" style={{ marginTop: 8 }}>Both are refused because the signed TideCloak token has no <code>doctor</code> role, and the attempt is logged.</p>
        </div>
        <div className="card">
          <div className="spread"><h2>Admin tries to give himself the doctor role</h2><Tag kind="real" /></div>
          <ol className="steps small">
            <li>Open the <a href={TIDE_CONSOLE} target="_blank" rel="noreferrer">Tide console</a> and sign in as the IT admin.</li>
            <li>People → your user → assign realm role <code>doctor</code>.</li>
            <li>TideCloak does <strong>not</strong> apply it. It parks a change request in <strong>QEA Approvals</strong>.</li>
            <li>With 3 admins (IT admin, director, compliance) the threshold is max(1, ⌊0.7×3⌋) = <strong>2</strong>. Your own Authorize counts once, so it stays pending until another admin authorizes it in their Tide enclave.</li>
          </ol>
          <p className="small muted">This is enforced with threshold signatures by the Tide Fabric, not by MedQuorum code.</p>
        </div>
      </div>

      <div className="card section">
        <div className="spread"><h2>Threat simulator</h2><Tag kind="sim" /></div>
        <p className="small muted">Plays a party trying to act alone. The attacks are simulated; the system&apos;s responses (denials, integrity alerts, chain breaks) are real.</p>
        <div className="row">
          <button onClick={() => sim('ai-bulk-read')}>AI service bulk-reads recordings</button>
          <button onClick={() => sim('tamper-blob')} disabled={!caseId}>Insider edits stored record</button>
          <button className="small" onClick={() => sim('restore-blob')} disabled={!caseId}>restore</button>
          <button onClick={() => sim('tamper-audit')}>Insider rewrites audit entry</button>
          <button className="small" onClick={() => sim('restore-audit')}>restore</button>
        </div>
        <p className="small muted" style={{ marginTop: 8 }}>After tampering, use <strong>Verify integrity</strong> on the <Link href={caseId ? `/cases/${caseId}` : '/cases'}>case page</Link> and check the <Link href="/audit">Audit trail</Link>.</p>
      </div>

      <div className="card section">
        <div className="spread"><h2>Raw database view</h2><span className="badge b-ok">what a DB admin or thief sees</span></div>
        <table>
          <thead><tr><th>Case</th><th>Patient details (stored)</th><th>Video (stored)</th><th>Escrowed key (wrapped)</th></tr></thead>
          <tbody>
            {(d?.cases || []).map((c: any) => (
              <tr key={c.id}>
                <td>{c.id}<div className="small muted">{c.status}</div></td>
                <td><div className="cipher">{c.ciphertextDetails ? c.ciphertextDetails + '…' : '(shredded)'}</div></td>
                <td><div className="cipher">{c.ciphertextVideo ? c.ciphertextVideo + '…' : '(shredded)'}</div></td>
                <td><div className="cipher">{c.escrowedKey}</div></td>
              </tr>
            ))}
          </tbody>
        </table>
        <h3 style={{ marginTop: 14 }}>Personal vaults (Tide E2EE)</h3>
        <table>
          <tbody>
            {(d?.vaults || []).map((v: any) => <tr key={v.username}><td>{v.username}</td><td><div className="cipher">{v.ciphertext}…</div></td></tr>)}
            {d && d.vaults.length === 0 && <tr><td className="muted">No vaults saved yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </Shell>
  )
}
