import { NextRequest, NextResponse } from 'next/server'
import { getUser, unauthorized } from '@/lib/server/auth'
import { mutate, nowIso, readDB } from '@/lib/server/store'
import { appendAudit } from '@/lib/server/audit'

// Personal health vault. The browser encrypts with TideCloak doEncrypt (tag "vault")
// BEFORE sending, so this endpoint only ever receives and stores ciphertext.
export async function GET(req: NextRequest) {
  const u = await getUser(req)
  if (!u) return unauthorized()
  const v = readDB().vaults.find((x) => x.username === u.username) || null
  return NextResponse.json({ vault: v })
}

export async function PUT(req: NextRequest) {
  const u = await getUser(req)
  if (!u) return unauthorized()
  const b = await req.json().catch(() => ({}))
  if (typeof b.ciphertext !== 'string' || !b.ciphertext) return NextResponse.json({ error: 'ciphertext required' }, { status: 400 })
  const v = await mutate((db) => {
    db.vaults = db.vaults.filter((x) => x.username !== u.username)
    const v = { username: u.username, ciphertext: b.ciphertext, updatedAt: nowIso(), mode: u.mode }
    db.vaults.push(v)
    appendAudit(db, { actor: u.username, actorRoles: u.roles, action: 'VAULT_SAVE', outcome: 'OK', detail: `Personal vault updated (${b.ciphertext.length} chars of Tide ciphertext; server never saw plaintext)` })
    return v
  })
  return NextResponse.json({ vault: v })
}
