import { NextRequest, NextResponse } from 'next/server'
import { getUser, unauthorized, forbidden } from '@/lib/server/auth'
import { mutate } from '@/lib/server/store'
import { appendAudit } from '@/lib/server/audit'
import { canFillSlot, refreshStatus } from '@/lib/server/policy'

// Any eligible approver (e.g. the patient) can refuse. One "no" stops the request.
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const u = await getUser(req)
  if (!u) return unauthorized()
  const { id } = await params
  const out = await mutate((db) => {
    const r = db.requests.find((x) => x.id === id)
    if (!r) return { status: 404, body: { error: 'not found' } }
    refreshStatus(r)
    if (r.status !== 'pending') return { status: 409, body: { error: `request is ${r.status}` } }
    if (!r.slots.some((s) => canFillSlot(u, r, s).ok)) return { status: 403, body: { error: 'You are not an eligible approver for this request.' } }
    r.status = 'denied'
    r.deniedBy = u.username
    appendAudit(db, { actor: u.username, actorRoles: u.roles, action: 'DENY', outcome: 'OK', caseId: r.caseId, detail: `${r.id} refused by ${u.username}` })
    return { status: 200, body: { request: r } }
  })
  if (out.status === 403) return forbidden((out.body as any).error)
  return NextResponse.json(out.body, { status: out.status })
}
