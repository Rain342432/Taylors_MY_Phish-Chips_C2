import { NextRequest, NextResponse } from 'next/server'
import fs from 'node:fs'
import path from 'node:path'
import { getUser, unauthorized, forbidden } from '@/lib/server/auth'
import { BLOB_DIR, mutate, nowIso } from '@/lib/server/store'
import { appendAudit } from '@/lib/server/audit'
import { POLICIES, canFillSlot, refreshStatus } from '@/lib/server/policy'
import { shredKey } from '@/lib/server/krs'

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const u = await getUser(req)
  if (!u) return unauthorized()
  const { id } = await params
  const b = await req.json().catch(() => ({}))
  const out = await mutate((db) => {
    const r = db.requests.find((x) => x.id === id)
    if (!r) return { status: 404, body: { error: 'not found' } }
    refreshStatus(r)
    if (r.status !== 'pending') return { status: 409, body: { error: `request is ${r.status}` } }
    const idx = typeof b.slot === 'number' ? b.slot : r.slots.findIndex((s) => canFillSlot(u, r, s).ok)
    const slot = r.slots[idx]
    const check = slot ? canFillSlot(u, r, slot) : { ok: false, why: 'you are not an eligible approver for this request' }
    if (!check.ok) {
      appendAudit(db, { actor: u.username, actorRoles: u.roles, action: 'APPROVE', outcome: 'DENIED', caseId: r.caseId, detail: `Approval of ${r.id} rejected: ${check.why}` })
      return { status: 403, body: { error: `Approval rejected: ${check.why}` } }
    }
    slot.approvedBy = u.username
    slot.at = nowIso()
    const done = r.slots.every((s) => s.approvedBy)
    appendAudit(db, { actor: u.username, actorRoles: u.roles, action: 'APPROVE', outcome: 'OK', caseId: r.caseId, detail: `${slot.label} given for ${r.id} (${r.slots.filter((s) => s.approvedBy).length}/${r.slots.length})` })
    if (done && r.kind === 'access') {
      r.status = 'approved'
      const mins = POLICIES[r.mode as 'consent'].grantMinutes
      r.grantExpiresAt = new Date(Date.now() + mins * 60_000).toISOString()
      appendAudit(db, { actor: 'quorum', actorRoles: ['policy'], action: 'QUORUM_MET', outcome: 'OK', caseId: r.caseId, detail: `${r.id}: ${r.requester} may open the record until ${r.grantExpiresAt} (${mins} min)` })
      const c = db.cases.find((x) => x.id === r.caseId)
      if (c && r.mode === 'breakglass') db.notifications.push({ id: `N-${Date.now()}`, to: c.patientUsername, at: nowIso(), text: `BREAK-GLASS GRANTED on your record ${c.id} to ${r.requester} for 30 minutes (approved by ${r.slots.map((s) => s.approvedBy).join(', ')}).` })
    }
    if (done && r.kind === 'deletion') {
      const c = db.cases.find((x) => x.id === r.caseId)
      if (c) {
        shredKey(c.id)
        const f = path.join(BLOB_DIR, `${c.id}.json`)
        if (fs.existsSync(f)) fs.rmSync(f)
        c.status = 'shredded'
      }
      r.status = 'executed'
      appendAudit(db, { actor: 'quorum', actorRoles: ['policy'], action: 'CRYPTO_SHRED', outcome: 'OK', caseId: r.caseId, detail: `${r.id}: case key destroyed and ciphertext removed. This audit history is retained.` })
    }
    return { status: 200, body: { request: r } }
  })
  if (out.status === 403) return forbidden((out.body as any).error)
  return NextResponse.json(out.body, { status: out.status })
}
