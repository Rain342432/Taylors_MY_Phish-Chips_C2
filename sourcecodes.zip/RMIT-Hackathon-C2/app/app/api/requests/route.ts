import { NextRequest, NextResponse } from 'next/server'
import { getUser, has, unauthorized } from '@/lib/server/auth'
import { readDB, writeDB } from '@/lib/server/store'
import { canFillSlot, refreshStatus } from '@/lib/server/policy'

// Approvals inbox: requests I can approve, requests I made, and (for oversight
// roles) every request.
export async function GET(req: NextRequest) {
  const u = await getUser(req)
  if (!u) return unauthorized()
  const db = readDB()
  db.requests.forEach((r) => refreshStatus(r))
  writeDB(db)
  const oversight = has(u, 'compliance_officer') || has(u, 'hospital_director')
  const list = db.requests
    .map((r) => {
      const fillable = r.status === 'pending' ? r.slots.map((s, i) => ({ i, ...canFillSlot(u, r, s) })).filter((x) => x.ok).map((x) => x.i) : []
      return { ...r, fillable, mine: r.requester === u.username }
    })
    .filter((r) => r.fillable.length > 0 || r.mine || oversight || r.slots.some((s) => s.user === u.username))
    .reverse()
  return NextResponse.json({ requests: list })
}
