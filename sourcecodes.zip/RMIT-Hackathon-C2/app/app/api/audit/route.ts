import { NextRequest, NextResponse } from 'next/server'
import { getUser, has, unauthorized } from '@/lib/server/auth'
import { readDB } from '@/lib/server/store'
import { verifyAudit } from '@/lib/server/audit'

// Oversight roles see the full chain; patients / NoK see every event on their
// own records; everyone else sees their own actions. Integrity is always verified
// over the FULL chain.
export async function GET(req: NextRequest) {
  const u = await getUser(req)
  if (!u) return unauthorized()
  const db = readDB()
  const integrity = verifyAudit(db.audit)
  const full = ['compliance_officer', 'hospital_director', 'it_admin'].some((r) => has(u, r))
  const myCases = new Set(db.cases.filter((c) => c.patientUsername === u.username || c.nokUsername === u.username).map((c) => c.id))
  const entries = full ? db.audit : db.audit.filter((e) => e.actor === u.username || (e.caseId && myCases.has(e.caseId)))
  return NextResponse.json({ integrity, scope: full ? 'full' : 'mine', entries: [...entries].reverse() })
}
