import { NextRequest, NextResponse } from 'next/server'
import fs from 'node:fs'
import path from 'node:path'
import { getUser, has, unauthorized, forbidden } from '@/lib/server/auth'
import { BLOB_DIR, DATA_DIR, mutate } from '@/lib/server/store'
import { appendAudit } from '@/lib/server/audit'

// Threat simulator (SIMULATED ATTACKS, for the demo). Each one plays a party
// trying to act unilaterally, and shows the system's real response.
export async function POST(req: NextRequest) {
  const u = await getUser(req)
  if (!u) return unauthorized()
  if (!has(u, 'it_admin') && !has(u, 'compliance_officer')) return forbidden('IT admin or compliance officer only.')
  const { kind, caseId } = await req.json().catch(() => ({}))

  if (kind === 'ai-bulk-read') {
    // The organisation's own AI service tries to pull every recording "for training".
    const out = await mutate((db) => {
      const ids = db.cases.filter((c) => c.status === 'sealed').map((c) => c.id)
      for (const id of ids) appendAudit(db, { actor: 'ai-triage-local', actorRoles: ['ai_system'], action: 'KEY_RELEASE', outcome: 'DENIED', caseId: id, detail: 'AI service has no human TideCloak identity and no quorum grant. AI may suggest, never read stored records.' })
      return ids.length
    })
    return NextResponse.json({ result: `AI service attempted to read ${out} sealed record(s): all ${out} DENIED and logged.` })
  }

  if (kind === 'tamper-blob' || kind === 'restore-blob') {
    const f = path.join(BLOB_DIR, `${caseId}.json`)
    if (!caseId || !fs.existsSync(f)) return NextResponse.json({ error: 'pick an existing sealed case' }, { status: 400 })
    if (kind === 'tamper-blob') {
      const s = fs.readFileSync(f, 'utf8')
      if (!fs.existsSync(f + '.orig')) fs.writeFileSync(f + '.orig', s)
      const i = s.indexOf('"ct":"') + 12
      const ch = s[i] === 'A' ? 'B' : 'A'
      fs.writeFileSync(f, s.slice(0, i) + ch + s.slice(i + 1))
      await mutate((db) => appendAudit(db, { actor: u.username, actorRoles: u.roles, action: 'SIMULATION', outcome: 'OK', caseId, detail: 'SIMULATED rogue insider edited one byte of the stored record directly on disk' }))
      return NextResponse.json({ result: 'One byte of the stored ciphertext was changed directly on disk (simulating a rogue DB admin). Now run "Verify integrity" on the case.' })
    }
    if (fs.existsSync(f + '.orig')) { fs.copyFileSync(f + '.orig', f); fs.rmSync(f + '.orig') }
    return NextResponse.json({ result: 'Original ciphertext restored.' })
  }

  if (kind === 'tamper-audit' || kind === 'restore-audit') {
    const bak = path.join(DATA_DIR, 'audit.orig.json')
    const r = await mutate((db) => {
      if (kind === 'tamper-audit') {
        const victim = db.audit.find((e) => e.action === 'KEY_RELEASE' && e.outcome === 'OK') || db.audit.find((e) => e.action === 'APPROVE') || db.audit[0]
        if (!victim) return 'Audit log is empty - do some actions first.'
        if (fs.existsSync(bak)) return 'An entry is already tampered - restore it first.'
        fs.writeFileSync(bak, JSON.stringify({ seq: victim.seq, detail: victim.detail }))
        victim.detail = '(entry quietly rewritten by an insider to hide who accessed the record)'
        return `Audit entry #${victim.seq} was rewritten in the database. Open the Audit page - the chain check will flag it.`
      }
      if (fs.existsSync(bak)) {
        const o = JSON.parse(fs.readFileSync(bak, 'utf8'))
        const e = db.audit.find((x) => x.seq === o.seq)
        if (e) e.detail = o.detail
        fs.rmSync(bak)
        return `Audit entry #${o.seq} restored - chain is valid again.`
      }
      return 'Nothing to restore.'
    })
    return NextResponse.json({ result: r })
  }

  return NextResponse.json({ error: 'unknown simulation' }, { status: 400 })
}
