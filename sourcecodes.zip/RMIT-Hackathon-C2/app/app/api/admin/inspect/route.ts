import { NextRequest, NextResponse } from 'next/server'
import fs from 'node:fs'
import path from 'node:path'
import { getUser, has, unauthorized, forbidden } from '@/lib/server/auth'
import { BLOB_DIR, mutate, readDB } from '@/lib/server/store'
import { appendAudit } from '@/lib/server/audit'
import { wrappedKeyPreview } from '@/lib/server/krs'

// "Raw database view" - exactly what an administrator (or an attacker who steals
// the database) can see. Shows that every sensitive field is ciphertext.
export async function GET(req: NextRequest) {
  const u = await getUser(req)
  if (!u) return unauthorized()
  if (!has(u, 'it_admin') && !has(u, 'compliance_officer')) return forbidden('IT admin or compliance officer only.')
  const db = readDB()
  const cases = db.cases.map((c) => {
    const f = path.join(BLOB_DIR, `${c.id}.json`)
    let details = null, video = null
    if (fs.existsSync(f)) {
      const b = JSON.parse(fs.readFileSync(f, 'utf8'))
      details = String(b.details?.ct || '').slice(0, 160)
      video = String(b.video?.ct || '').slice(0, 160)
    }
    return { ...c, ciphertextDetails: details, ciphertextVideo: video, escrowedKey: (wrappedKeyPreview(c.id) || '(destroyed)').slice(0, 48) }
  })
  const vaults = db.vaults.map((v) => ({ username: v.username, ciphertext: v.ciphertext.slice(0, 160), updatedAt: v.updatedAt }))
  await mutate((d) => appendAudit(d, { actor: u.username, actorRoles: u.roles, action: 'DB_INSPECT', outcome: 'OK', detail: 'Viewed raw database (ciphertext only)' }))
  return NextResponse.json({ cases, vaults })
}
