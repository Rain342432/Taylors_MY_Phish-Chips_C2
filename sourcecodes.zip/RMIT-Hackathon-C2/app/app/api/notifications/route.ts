import { NextRequest, NextResponse } from 'next/server'
import { getUser, unauthorized } from '@/lib/server/auth'
import { readDB } from '@/lib/server/store'

export async function GET(req: NextRequest) {
  const u = await getUser(req)
  if (!u) return unauthorized()
  return NextResponse.json({ notifications: readDB().notifications.filter((n) => n.to === u.username).reverse() })
}
