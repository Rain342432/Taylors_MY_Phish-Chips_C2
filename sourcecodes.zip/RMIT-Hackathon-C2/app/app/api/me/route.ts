import { NextRequest, NextResponse } from 'next/server'
import { getUser, unauthorized, MOCK } from '@/lib/server/auth'
import { mutate } from '@/lib/server/store'
import { appendAudit } from '@/lib/server/audit'

// Returns the identity exactly as the SERVER sees it after verifying the TideCloak token.
export async function GET(req: NextRequest) {
  const u = await getUser(req)
  if (!u) return unauthorized()
  return NextResponse.json({ ...u, mock: MOCK })
}

// Called once after login so sign-ins appear in the audit trail.
export async function POST(req: NextRequest) {
  const u = await getUser(req)
  if (!u) return unauthorized()
  await mutate((db) => appendAudit(db, { actor: u.username, actorRoles: u.roles, action: 'SIGN_IN', outcome: 'OK', detail: `Signed in via ${u.mode === 'tide' ? 'TideCloak (Tide BYOiD)' : 'MOCK auth'}` }))
  return NextResponse.json({ ok: true })
}
