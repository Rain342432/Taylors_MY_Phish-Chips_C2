import { NextRequest, NextResponse } from 'next/server'
import { getUser, has, unauthorized, forbidden } from '@/lib/server/auth'
import { mutate } from '@/lib/server/store'
import { appendAudit } from '@/lib/server/audit'
import { grantActive, refreshStatus } from '@/lib/server/policy'
import { releaseKey } from '@/lib/server/krs'

// The ONLY way to obtain a case key. Requires, all at once:
//  1. a valid TideCloak token (identity proven by Tide, not by our DB),
//  2. the TideCloak role 'doctor' (granted only via quorum-approved change request),
//  3. an access request by THIS doctor whose approval quorum is complete and unexpired.
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const u = await getUser(req)
  if (!u) return unauthorized()
  const { id } = await params
  const result = await mutate((db) => {
    const c = db.cases.find((x) => x.id === id)
    if (!c) return { status: 404, body: { error: 'not found' } }
    if (c.status === 'shredded') return { status: 410, body: { error: 'Record was crypto-shredded after a quorum-approved deletion.' } }
    if (!has(u, 'doctor')) {
      appendAudit(db, { actor: u.username, actorRoles: u.roles, action: 'KEY_RELEASE', outcome: 'DENIED', caseId: id, detail: 'Not a TideCloak-verified doctor. Admin/organisation roles cannot read patient data.' })
      return { status: 403, body: { error: 'Denied: only a TideCloak-verified doctor with an approved quorum can open this record. Your role does not grant data access - not even as administrator.' } }
    }
    const grant = db.requests.map((r) => refreshStatus(r)).find((r) => r.caseId === id && r.requester === u.username && grantActive(r))
    if (!grant) {
      appendAudit(db, { actor: u.username, actorRoles: u.roles, action: 'KEY_RELEASE', outcome: 'DENIED', caseId: id, detail: 'No approved, unexpired access request (quorum not met)' })
      return { status: 403, body: { error: 'Denied: no approved access request. Submit a request and wait for the required approvals.' } }
    }
    const key = releaseKey(id)
    if (!key) return { status: 410, body: { error: 'Key no longer exists' } }
    appendAudit(db, { actor: u.username, actorRoles: u.roles, action: 'KEY_RELEASE', outcome: 'OK', caseId: id, detail: `Case key released under ${grant.mode} request ${grant.id}; grant expires ${grant.grantExpiresAt}` })
    return { status: 200, body: { key, grant } }
  })
  if (result.status === 403) return forbidden((result.body as any).error)
  return NextResponse.json(result.body, { status: result.status })
}
