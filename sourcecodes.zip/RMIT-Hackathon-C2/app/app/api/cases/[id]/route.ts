import { NextRequest, NextResponse } from 'next/server'
import { getUser, unauthorized } from '@/lib/server/auth'
import { readDB } from '@/lib/server/store'
import { canFillSlot, grantActive, refreshStatus } from '@/lib/server/policy'

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const u = await getUser(req)
  if (!u) return unauthorized()
  const { id } = await params
  const db = readDB()
  const c = db.cases.find((x) => x.id === id)
  if (!c) return NextResponse.json({ error: 'not found' }, { status: 404 })
  const requests = db.requests
    .filter((r) => r.caseId === id)
    .map((r) => refreshStatus(r))
    .map((r) => ({ ...r, fillable: r.status === 'pending' ? r.slots.map((s, i) => (canFillSlot(u, r, s).ok ? i : -1)).filter((i) => i >= 0) : [] }))
    .reverse()
  const myGrant = requests.find((r) => r.requester === u.username && grantActive(r)) || null
  return NextResponse.json({ case: c, requests, myGrant })
}
