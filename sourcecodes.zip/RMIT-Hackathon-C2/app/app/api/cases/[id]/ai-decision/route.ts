import { NextRequest, NextResponse } from 'next/server'
import { getUser, has, unauthorized, forbidden } from '@/lib/server/auth'
import { mutate, nowIso } from '@/lib/server/store'
import { appendAudit } from '@/lib/server/audit'
import { grantActive } from '@/lib/server/policy'

// The AI can only SUGGEST. A human doctor with an active, quorum-approved grant
// must confirm or override - the AI never makes the decision on its own.
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const u = await getUser(req)
  if (!u) return unauthorized()
  const { id } = await params
  const b = await req.json().catch(() => ({}))
  const out = await mutate((db) => {
    const c = db.cases.find((x) => x.id === id)
    if (!c) return { status: 404, body: { error: 'not found' } }
    const grant = db.requests.find((r) => r.caseId === id && r.requester === u.username && grantActive(r))
    if (!has(u, 'doctor') || !grant) {
      appendAudit(db, { actor: u.username, actorRoles: u.roles, action: 'AI_DECISION', outcome: 'DENIED', caseId: id, detail: 'Only a doctor with an active approved grant can confirm/override AI' })
      return { status: 403, body: { error: 'Only a doctor with an active approved access grant can confirm or override the AI suggestion.' } }
    }
    const decision = b.decision === 'overridden' ? 'overridden' : 'confirmed'
    c.aiDecision = { by: u.username, decision, finalPriority: String(b.finalPriority || c.aiPriority), at: nowIso() }
    appendAudit(db, { actor: u.username, actorRoles: u.roles, action: 'AI_DECISION', outcome: 'OK', caseId: id, detail: `Doctor ${decision} AI suggestion (${c.aiPriority}) -> final ${c.aiDecision.finalPriority}` })
    return { status: 200, body: { case: c } }
  })
  if (out.status === 403) return forbidden((out.body as any).error)
  return NextResponse.json(out.body, { status: out.status })
}
