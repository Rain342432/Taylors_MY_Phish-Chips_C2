import { NextRequest, NextResponse } from 'next/server'
import { getUser, has, unauthorized, forbidden } from '@/lib/server/auth'
import { mutate, newId, nowIso } from '@/lib/server/store'
import { appendAudit } from '@/lib/server/audit'
import { POLICIES } from '@/lib/server/policy'

// A doctor asks for access. Nothing is released here - this only opens a request
// that other, independent people must approve.
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const u = await getUser(req)
  if (!u) return unauthorized()
  const { id } = await params
  const b = await req.json().catch(() => ({}))
  const mode = b.mode as 'consent' | 'proxy' | 'breakglass'
  if (!['consent', 'proxy', 'breakglass'].includes(mode)) return NextResponse.json({ error: 'mode must be consent | proxy | breakglass' }, { status: 400 })
  const out = await mutate((db) => {
    const c = db.cases.find((x) => x.id === id)
    if (!c) return { status: 404, body: { error: 'not found' } }
    if (!has(u, 'doctor')) {
      appendAudit(db, { actor: u.username, actorRoles: u.roles, action: 'REQUEST_ACCESS', outcome: 'DENIED', caseId: id, detail: 'Only a TideCloak-verified doctor may request access' })
      return { status: 403, body: { error: 'Only a TideCloak-verified doctor may request access to a patient record.' } }
    }
    const pol = POLICIES[mode]
    const r = {
      id: newId('REQ'),
      kind: 'access' as const,
      caseId: id,
      requester: u.username,
      requesterRoles: u.roles,
      mode,
      reason: String(b.reason || '').slice(0, 300),
      createdAt: nowIso(),
      pendingExpiresAt: new Date(Date.now() + 30 * 60_000).toISOString(),
      slots: pol.slots(c).map((s) => ({ ...s })),
      status: 'pending' as const,
    }
    db.requests.push(r)
    appendAudit(db, { actor: u.username, actorRoles: u.roles, action: 'REQUEST_ACCESS', outcome: 'PENDING', caseId: id, detail: `${pol.title}: needs ${r.slots.map((s) => s.label + (s.user ? ` (${s.user})` : '')).join(' + ')}. Reason: ${r.reason || '-'}` })
    if (mode === 'breakglass') {
      db.notifications.push({ id: newId('N'), to: c.patientUsername, at: nowIso(), text: `BREAK-GLASS requested on your record ${id} by ${u.username}: "${r.reason || 'no reason given'}". You will see every access in your audit trail.` })
      if (c.nokUsername) db.notifications.push({ id: newId('N'), to: c.nokUsername, at: nowIso(), text: `BREAK-GLASS requested on ${c.patientUsername}'s record ${id} by ${u.username}.` })
    }
    return { status: 200, body: { request: r } }
  })
  if (out.status === 403) return forbidden((out.body as any).error)
  return NextResponse.json(out.body, { status: out.status })
}
