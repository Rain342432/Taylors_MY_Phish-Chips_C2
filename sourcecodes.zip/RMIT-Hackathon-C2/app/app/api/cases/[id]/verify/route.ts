import { NextRequest, NextResponse } from 'next/server'
import fs from 'node:fs'
import path from 'node:path'
import { getUser, unauthorized } from '@/lib/server/auth'
import { BLOB_DIR, mutate, sha256 } from '@/lib/server/store'
import { appendAudit } from '@/lib/server/audit'

// Integrity check: recompute the ciphertext hash and compare with the hash sealed
// (and chained into the audit log) at capture time. Any silent edit is detected.
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const u = await getUser(req)
  if (!u) return unauthorized()
  const { id } = await params
  const out = await mutate((db) => {
    const c = db.cases.find((x) => x.id === id)
    if (!c) return { status: 404, body: { error: 'not found' } }
    const f = path.join(BLOB_DIR, `${id}.json`)
    if (!fs.existsSync(f)) return { status: 200, body: { ok: c.status === 'shredded', shredded: c.status === 'shredded', sealedHash: c.sealedHash, currentHash: null } }
    const currentHash = sha256(fs.readFileSync(f, 'utf8'))
    const ok = currentHash === c.sealedHash
    if (!ok) appendAudit(db, { actor: 'integrity-monitor', actorRoles: ['system'], action: 'INTEGRITY_CHECK', outcome: 'ALERT', caseId: id, detail: `Stored ciphertext hash ${currentHash.slice(0, 16)}… != sealed ${c.sealedHash.slice(0, 16)}… - record was altered outside the app` })
    return { status: 200, body: { ok, sealedHash: c.sealedHash, currentHash } }
  })
  return NextResponse.json(out.body, { status: out.status })
}
