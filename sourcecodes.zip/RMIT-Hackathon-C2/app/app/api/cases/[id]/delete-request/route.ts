import { NextRequest, NextResponse } from 'next/server'
import { getUser, has, unauthorized, forbidden } from '@/lib/server/auth'
import { mutate, newId, nowIso } from '@/lib/server/store'
import { appendAudit } from '@/lib/server/audit'
import { POLICIES } from '@/lib/server/policy'

// The organisation (director / IT admin) cannot delete or alter a record alone.
// A deletion request needs the compliance officer AND the patient (data owner).
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const u = await getUser(req)
  if (!u) return unauthorized()
  const { id } = await params
  const b = await req.json().catch(() => ({}))
  const out = await mutate((db) => {
    const c = db.cases.find((x) => x.id === id)
    if (!c) return { status: 404, body: { error: 'not found' } }
    if (!has(u, 'hospital_director') && !has(u, 'it_admin')) {
      appendAudit(db, { actor: u.username, actorRoles: u.roles, action: 'REQUEST_DELETION', outcome: 'DENIED', caseId: id, detail: 'Only organisation roles may propose deletion' })
      return { status: 403, body: { error: 'Only the hospital director or IT admin may propose a deletion - and even they cannot execute it alone.' } }
    }
    const r = {
      id: newId('DEL'),
      kind: 'deletion' as const,
      caseId: id,
      requester: u.username,
      requesterRoles: u.roles,
      mode: 'deletion' as const,
      reason: String(b.reason || '').slice(0, 300),
      createdAt: nowIso(),
      pendingExpiresAt: new Date(Date.now() + 24 * 60 * 60_000).toISOString(),
      slots: POLICIES.deletion.slots(c).map((s) => ({ ...s })),
      status: 'pending' as const,
    }
    db.requests.push(r)
    appendAudit(db, { actor: u.username, actorRoles: u.roles, action: 'REQUEST_DELETION', outcome: 'PENDING', caseId: id, detail: `Attempted delete was NOT executed. Parked as ${r.id}, needs compliance officer + patient (${c.patientUsername}). Reason: ${r.reason || '-'}` })
    db.notifications.push({ id: newId('N'), to: c.patientUsername, at: nowIso(), text: `${u.username} asked to DELETE your record ${id}. It cannot happen without your approval.` })
    return { status: 202, body: { request: r, message: 'Deletion was not executed. It is pending multi-party approval.' } }
  })
  if (out.status === 403) return forbidden((out.body as any).error)
  return NextResponse.json(out.body, { status: out.status })
}
