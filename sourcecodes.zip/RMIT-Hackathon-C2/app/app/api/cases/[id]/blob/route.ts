import { NextRequest, NextResponse } from 'next/server'
import fs from 'node:fs'
import path from 'node:path'
import { getUser, unauthorized } from '@/lib/server/auth'
import { BLOB_DIR } from '@/lib/server/store'

// Returns the sealed CIPHERTEXT. Useless without the case key, which only the
// Key Release Service hands out after a quorum - so this needs only a valid login.
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const u = await getUser(req)
  if (!u) return unauthorized()
  const { id } = await params
  const f = path.join(BLOB_DIR, `${id}.json`)
  if (!/^CASE-[0-9a-f]+$/.test(id) || !fs.existsSync(f)) return NextResponse.json({ error: 'not found (or crypto-shredded)' }, { status: 404 })
  return new NextResponse(fs.readFileSync(f, 'utf8'), { headers: { 'content-type': 'application/json' } })
}
