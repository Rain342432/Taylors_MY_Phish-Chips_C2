import { NextRequest, NextResponse } from 'next/server'
import fs from 'node:fs'
import path from 'node:path'
import { getUser, has, unauthorized, forbidden } from '@/lib/server/auth'
import { BLOB_DIR, mutate, newId, nowIso, readDB, sha256 } from '@/lib/server/store'
import { appendAudit } from '@/lib/server/audit'
import { escrowKey } from '@/lib/server/krs'
import { grantActive, refreshStatus } from '@/lib/server/policy'

// List cases visible to the caller. Only non-identifying metadata is ever returned.
export async function GET(req: NextRequest) {
  const u = await getUser(req)
  if (!u) return unauthorized()
  const db = readDB()
  const seeAll = ['doctor', 'compliance_officer', 'hospital_director', 'it_admin'].some((r) => has(u, r))
  const cases = db.cases
    .filter((c) => seeAll || c.paramedic === u.username || c.patientUsername === u.username || c.nokUsername === u.username)
    .map((c) => {
      const mine = db.requests.filter((r) => r.caseId === c.id && r.requester === u.username).map((r) => refreshStatus(r))
      return { ...c, myActiveGrant: mine.find((r) => grantActive(r)) || null, myRequests: mine }
    })
    .reverse()
  return NextResponse.json({ cases })
}

// Paramedic seals a new case. Body contains ONLY ciphertext (AES-256-GCM, encrypted
// in the paramedic's browser) plus the case key for escrow in the Key Release Service.
export async function POST(req: NextRequest) {
  const u = await getUser(req)
  if (!u) return unauthorized()
  if (!has(u, 'paramedic')) {
    await mutate((db) => appendAudit(db, { actor: u.username, actorRoles: u.roles, action: 'CREATE_CASE', outcome: 'DENIED', detail: 'Only TideCloak role paramedic may create case records' }))
    return forbidden('Only a TideCloak-verified paramedic can create case records.')
  }
  const b = await req.json()
  for (const k of ['patientUsername', 'nokUsername', 'encDetails', 'encVideo', 'caseKey']) {
    if (!b[k]) return NextResponse.json({ error: `missing ${k}` }, { status: 400 })
  }
  const id = newId('CASE')
  const blob = JSON.stringify({ v: 1, alg: 'AES-256-GCM', details: b.encDetails, video: b.encVideo })
  fs.mkdirSync(BLOB_DIR, { recursive: true })
  fs.writeFileSync(path.join(BLOB_DIR, `${id}.json`), blob)
  escrowKey(id, b.caseKey)
  const sealedHash = sha256(blob)
  const rec = await mutate((db) => {
    const c = {
      id,
      createdAt: nowIso(),
      paramedic: u.username,
      patientUsername: String(b.patientUsername).trim(),
      nokUsername: String(b.nokUsername).trim(),
      incidentType: String(b.incidentType || 'Medical emergency'),
      aiPriority: String(b.aiPriority || 'unknown'),
      sealedHash,
      blobBytes: blob.length,
      status: 'sealed' as const,
    }
    db.cases.push(c)
    appendAudit(db, { actor: u.username, actorRoles: u.roles, action: 'SEAL_CASE', outcome: 'OK', caseId: id, detail: `Record encrypted on device and sealed. SHA-256 ${sealedHash.slice(0, 16)}… (${blob.length} bytes ciphertext). Case key escrowed in KRS.` })
    appendAudit(db, { actor: 'ai-triage-local', actorRoles: ['ai_system'], action: 'AI_SUGGESTION', outcome: 'OK', caseId: id, detail: `On-device model suggested ${c.aiPriority} - ADVISORY ONLY, awaiting doctor confirmation` })
    return c
  })
  return NextResponse.json({ case: rec })
}
