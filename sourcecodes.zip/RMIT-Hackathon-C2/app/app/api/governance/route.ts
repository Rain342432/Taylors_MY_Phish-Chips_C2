import { NextRequest, NextResponse } from 'next/server'
import { getUser, unauthorized, forbidden, MOCK, APP_ROLES } from '@/lib/server/auth'
import { kc, bearer } from '@/lib/server/kcadmin'

// Governance view: users, their app roles, and PENDING QEA change requests.
// Every call uses the caller's TideCloak token; TideCloak enforces permissions.
export async function GET(req: NextRequest) {
  if (MOCK) return NextResponse.json({ error: 'Governance needs a real TideCloak realm (not available in mock mode).' }, { status: 400 })
  const u = await getUser(req)
  if (!u) return unauthorized()
  if (!['it_admin', 'hospital_director', 'compliance_officer'].some((r) => u.roles.includes(r))) return forbidden('Admins only.')
  const t = bearer(req.headers.get('authorization'))
  const [users, pending] = await Promise.all([kc(t, '/users?max=100&briefRepresentation=true'), kc(t, '/iga/change-requests?status=PENDING')])
  let people: any[] = []
  if (Array.isArray(users.body)) {
    people = await Promise.all(
      users.body.map(async (x: any) => {
        const rm = await kc(t, `/users/${x.id}/role-mappings/realm`)
        const roles = Array.isArray(rm.body) ? rm.body.map((r: any) => r.name).filter((n: string) => APP_ROLES.includes(n)) : []
        return { id: x.id, username: x.username, roles }
      }),
    )
  }
  return NextResponse.json({
    users: people,
    usersStatus: users.status,
    pending: Array.isArray(pending.body) ? pending.body : [],
    pendingStatus: pending.status,
    pendingError: Array.isArray(pending.body) ? null : pending.body,
    appRoles: APP_ROLES,
  })
}
