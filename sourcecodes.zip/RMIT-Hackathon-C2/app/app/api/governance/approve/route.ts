import { NextRequest, NextResponse } from 'next/server'
import { getUser, unauthorized, MOCK } from '@/lib/server/auth'
import { kc, bearer } from '@/lib/server/kcadmin'
import { mutate } from '@/lib/server/store'
import { appendAudit } from '@/lib/server/audit'

// Record the caller's approval on a QEA change request. TideCloak counts distinct
// approvers and commits only when the quorum threshold is reached.
export async function POST(req: NextRequest) {
  if (MOCK) return NextResponse.json({ error: 'Not available in mock mode.' }, { status: 400 })
  const u = await getUser(req)
  if (!u) return unauthorized()
  const { id } = await req.json().catch(() => ({}))
  if (!id || !/^[A-Za-z0-9-]+$/.test(String(id))) return NextResponse.json({ error: 'change request id required' }, { status: 400 })
  const t = bearer(req.headers.get('authorization'))
  const r = await kc(t, `/iga/change-requests/${id}/approve`, { method: 'POST', body: '{}' })
  await mutate((db) => appendAudit(db, {
    actor: u.username, actorRoles: u.roles, action: 'QEA_APPROVE', outcome: r.status < 300 ? 'OK' : 'DENIED',
    detail: `Approval on TideCloak change request ${id}: HTTP ${r.status} ${typeof r.body === 'object' && r.body ? JSON.stringify({ committed: r.body.committed, authCount: r.body.authCount }) : ''}`,
  }))
  return NextResponse.json({ status: r.status, body: r.body }, { status: r.status >= 400 ? r.status : 200 })
}
