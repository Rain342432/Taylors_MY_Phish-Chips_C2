import { NextRequest, NextResponse } from 'next/server'
import { getUser, unauthorized, MOCK, APP_ROLES } from '@/lib/server/auth'
import { kc, bearer } from '@/lib/server/kcadmin'
import { mutate } from '@/lib/server/store'
import { appendAudit } from '@/lib/server/audit'

// Ask TideCloak to grant a realm role. Under QEA, TideCloak does NOT apply it:
// it answers 202 Accepted and parks a change request that needs the admin quorum.
export async function POST(req: NextRequest) {
  if (MOCK) return NextResponse.json({ error: 'Not available in mock mode.' }, { status: 400 })
  const u = await getUser(req)
  if (!u) return unauthorized()
  const { userId, username, role } = await req.json().catch(() => ({}))
  if (!userId || !APP_ROLES.includes(role)) return NextResponse.json({ error: 'userId and a valid app role are required' }, { status: 400 })
  const t = bearer(req.headers.get('authorization'))
  const roleRep = await kc(t, `/roles/${encodeURIComponent(role)}`)
  if (roleRep.status !== 200) return NextResponse.json({ error: `TideCloak refused to read role (${roleRep.status})`, detail: roleRep.body }, { status: roleRep.status })
  const r = await kc(t, `/users/${userId}/role-mappings/realm`, { method: 'POST', body: JSON.stringify([roleRep.body]) })
  const outcome = r.status === 202 ? 'PENDING' : r.status >= 200 && r.status < 300 ? 'OK' : 'DENIED'
  await mutate((db) => appendAudit(db, {
    actor: u.username, actorRoles: u.roles, action: 'ROLE_GRANT_REQUEST', outcome,
    detail: `Asked TideCloak to grant '${role}' to ${username || userId}: HTTP ${r.status}${r.status === 202 ? ' (parked as a QEA change request)' : ''}`,
  }))
  return NextResponse.json({ status: r.status, body: r.body }, { status: r.status >= 400 ? r.status : 200 })
}
