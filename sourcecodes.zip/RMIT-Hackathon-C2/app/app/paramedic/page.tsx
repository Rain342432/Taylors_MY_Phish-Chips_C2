'use client'
import { useEffect, useRef, useState } from 'react'
import Link from 'next/link'
import Shell, { Tag, Msg, RoleGate } from '@/components/Shell'
import RouteMap from '@/components/RouteMap'
import { useAuth, api } from '@/lib/client/auth'
import { runLocalTriage, type Triage } from '@/lib/client/ai'
import { newCaseKey, seal, enc } from '@/lib/client/crypto'

const DISPATCHES = [
  { id: 1, incident: 'Chest pain, male 58, conscious', patientName: 'Ahmad bin Ismail', address: '12 Jalan Ampang, 50450 Kuala Lumpur', phone: '+60 12-345 6789', conscious: true },
  { id: 2, incident: 'Unresponsive female 34, suspected fall', patientName: 'Mei Ling Tan', address: 'Block C-3-5, Taman Melawati, 53100 KL', phone: '+60 17-222 1100', conscious: false },
]

export default function Paramedic() {
  const auth = useAuth()
  const [d, setD] = useState(DISPATCHES[0])
  const [patientUser, setPatientUser] = useState('patient1')
  const [nokUser, setNokUser] = useState('nok1')
  const [notes, setNotes] = useState('')
  const [vitals, setVitals] = useState('HR 118, BP 92/60, SpO2 93%, GCS 15')
  const [video, setVideo] = useState<Blob | null>(null)
  const [videoUrl, setVideoUrl] = useState('')
  const [recording, setRecording] = useState(false)
  const [ai, setAi] = useState<Triage | null>(null)
  const [aiBusy, setAiBusy] = useState(false)
  const [busy, setBusy] = useState(false)
  const [msg, setMsg] = useState<{ kind: 'ok' | 'bad' | 'info'; text: string } | null>(null)
  const [sealed, setSealed] = useState<any>(null)
  const live = useRef<HTMLVideoElement>(null)
  const canvas = useRef<HTMLCanvasElement>(null)

  useEffect(() => { setVitals(d.conscious ? 'HR 118, BP 92/60, SpO2 93%, GCS 15' : 'HR 54, BP 88/50, SpO2 90%, GCS 7') }, [d])

  function record(stream: MediaStream, ms: number, stop?: () => void) {
    const mime = MediaRecorder.isTypeSupported('video/webm;codecs=vp8') ? 'video/webm;codecs=vp8' : 'video/webm'
    const rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 600_000 })
    const chunks: Blob[] = []
    rec.ondataavailable = (e) => e.data.size && chunks.push(e.data)
    rec.onstop = () => {
      stream.getTracks().forEach((t) => t.stop())
      stop?.()
      const b = new Blob(chunks, { type: 'video/webm' })
      setVideo(b)
      setVideoUrl(URL.createObjectURL(b))
      setRecording(false)
    }
    setRecording(true)
    rec.start(250)
    setTimeout(() => rec.state !== 'inactive' && rec.stop(), ms)
  }

  async function recordCamera() {
    setMsg(null)
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 360 }, audio: false })
      if (live.current) { live.current.srcObject = s; await live.current.play().catch(() => {}) }
      record(s, 6000, () => { if (live.current) live.current.srcObject = null })
    } catch (e: any) {
      setMsg({ kind: 'bad', text: `Camera unavailable (${e?.message || e}). Use "Generate test clip" instead.` })
    }
  }

  function recordTestClip() {
    const c = canvas.current!
    const ctx = c.getContext('2d')!
    let f = 0
    const timer = setInterval(() => {
      f++
      ctx.fillStyle = '#081426'; ctx.fillRect(0, 0, c.width, c.height)
      ctx.fillStyle = '#ff5d6c'; ctx.beginPath(); ctx.arc(320 + Math.sin(f / 6) * 120, 180, 40, 0, Math.PI * 2); ctx.fill()
      ctx.fillStyle = '#fff'; ctx.font = '22px sans-serif'
      ctx.fillText(`TEST CLIP · ${d.incident}`, 20, 40)
      ctx.fillText(new Date().toLocaleTimeString(), 20, 340)
    }, 40)
    record(c.captureStream(25), 4000, () => clearInterval(timer))
  }

  async function triage() {
    setAiBusy(true)
    setAi(await runLocalTriage(d.incident))
    setAiBusy(false)
  }

  async function sealAndUpload() {
    if (!video) return setMsg({ kind: 'bad', text: 'Record a clip first.' })
    setBusy(true); setMsg({ kind: 'info', text: 'Encrypting on this device (AES-256-GCM)...' })
    try {
      const { key, rawB64 } = await newCaseKey()
      const details = { patientName: d.patientName, address: d.address, phone: d.phone, incident: d.incident, conscious: d.conscious, vitals, fieldNotes: notes, aiTriage: ai, videoMime: video.type, capturedAt: new Date().toISOString(), capturedBy: auth.username }
      const encDetails = await seal(key, enc(JSON.stringify(details)))
      const encVideo = await seal(key, new Uint8Array(await video.arrayBuffer()))
      const r = await api(auth, '/api/cases', {
        method: 'POST',
        body: JSON.stringify({ patientUsername: patientUser, nokUsername: nokUser, incidentType: d.conscious ? 'Medical emergency (patient conscious)' : 'Medical emergency (patient unconscious)', aiPriority: ai ? `${ai.priority} (AI suggestion, unconfirmed)` : 'not assessed', encDetails, encVideo, caseKey: rawB64 }),
      })
      if (!r.ok) throw new Error(r.data?.error || `HTTP ${r.status}`)
      setSealed({ ...r.data.case, preview: encDetails.ct.slice(0, 120) })
      setMsg({ kind: 'ok', text: `Sealed as ${r.data.case.id}. Only ciphertext left this device. The plaintext and key have been discarded from this screen; you cannot re-open this record.` })
      setVideo(null); setVideoUrl(''); setAi(null); setNotes('')
    } catch (e: any) {
      setMsg({ kind: 'bad', text: `Failed: ${e.message}` })
    } finally {
      setBusy(false)
    }
  }

  return (
    <Shell>
      <RoleGate roles={['paramedic']} fallback={<div className="card section"><h2>Paramedics only</h2><p className="muted">Your TideCloak token does not carry the <code>paramedic</code> role.</p></div>}>
      <div className="section spread"><h1>Dispatch &amp; capture</h1><Tag kind="real" /></div>
      <div className="grid g2">
        <div className="card">
          <div className="spread"><h2>1 · Incoming dispatch</h2><span className="badge b-sim">SIMULATED CALL</span></div>
          <div className="row" style={{ marginBottom: 8 }}>
            {DISPATCHES.map((x) => <button key={x.id} className={x.id === d.id ? 'primary small' : 'small'} onClick={() => setD(x)}>Call #{x.id}</button>)}
          </div>
          <div className="kv">
            <div>Incident</div><div>{d.incident}</div>
            <div>Patient</div><div>{d.patientName}</div>
            <div>Address</div><div>{d.address}</div>
            <div>Caller phone</div><div>{d.phone}</div>
            <div>Conscious</div><div>{d.conscious ? 'Yes' : <strong style={{ color: 'var(--warn)' }}>No</strong>}</div>
          </div>
          <label>Patient&apos;s MedQuorum account (approves access)</label>
          <input value={patientUser} onChange={(e) => setPatientUser(e.target.value)} />
          <label>Registered next of kin account (proxy consent)</label>
          <input value={nokUser} onChange={(e) => setNokUser(e.target.value)} />
        </div>
        <div className="card">
          <h2>2 · Route to patient</h2>
          <RouteMap seed={d.id} />
        </div>
      </div>

      <div className="grid g2 section">
        <div className="card">
          <div className="spread"><h2>3 · Record on scene</h2><span className="badge b-ok">real camera capture</span></div>
          <video ref={live} muted playsInline style={{ display: recording ? 'block' : 'none' }} />
          {videoUrl && !recording && <video src={videoUrl} controls />}
          <canvas ref={canvas} width={640} height={360} style={{ display: 'none' }} />
          <div className="row" style={{ marginTop: 8 }}>
            <button onClick={recordCamera} disabled={recording}>Record 6s from webcam</button>
            <button onClick={recordTestClip} disabled={recording}>Generate test clip (no camera)</button>
            {recording && <span className="badge b-bad">● REC</span>}
          </div>
          <label>Vitals</label>
          <input value={vitals} onChange={(e) => setVitals(e.target.value)} />
          <label>Field notes</label>
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Observations, treatment given..." />
        </div>
        <div className="card">
          <div className="spread"><h2>4 · On-device AI triage</h2><Tag kind="sim" /></div>
          <p className="small muted">Organisation-owned model running locally. No external AI API, so nothing leaves the device. It can only <strong>suggest</strong>.</p>
          <button onClick={triage} disabled={aiBusy}>{aiBusy ? 'Analysing locally...' : 'Run local triage'}</button>
          {ai && (
            <div className="card soft" style={{ marginTop: 10 }}>
              <div className="spread"><strong>{ai.priority}</strong><span className="muted small">confidence {Math.round(ai.confidence * 100)}%</span></div>
              <ul className="small">{ai.observations.map((o) => <li key={o}>{o}</li>)}</ul>
              <div className="small muted">{ai.model}</div>
              <div className="badge b-warn" style={{ marginTop: 6 }}>{ai.disclaimer}</div>
            </div>
          )}
        </div>
      </div>

      <div className="card section">
        <div className="spread"><h2>5 · Seal &amp; upload</h2><span className="badge b-app">device-side AES-256-GCM · key escrow to KRS</span></div>
        <p className="small muted">The record (details, vitals, AI suggestion and video) is encrypted <strong>in this browser</strong> with a fresh key. The server receives ciphertext only. After sealing, the paramedic cannot open it again: access goes through the multi-party approval flow.</p>
        <button className="primary" onClick={sealAndUpload} disabled={busy || !video}>{busy ? 'Sealing...' : 'Encrypt, seal & upload'}</button>
        <Msg m={msg} />
        {sealed && (
          <div style={{ marginTop: 10 }}>
            <div className="small muted">What the server stored (first bytes of the ciphertext):</div>
            <div className="cipher">{sealed.preview}…</div>
            <div className="small" style={{ marginTop: 6 }}>Sealed SHA-256: <code>{sealed.sealedHash}</code></div>
            <Link href={`/cases/${sealed.id}`}>Open case page</Link>
          </div>
        )}
      </div>
      </RoleGate>
    </Shell>
  )
}
