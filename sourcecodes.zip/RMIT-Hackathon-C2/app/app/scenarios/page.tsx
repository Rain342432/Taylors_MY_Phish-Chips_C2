'use client'
import Shell, { Tag } from '@/components/Shell'
import { SCENARIOS } from '@/lib/scenarios'

export default function Scenarios() {
  return (
    <Shell requireAuth={false}>
      <div className="section"><h1>Demo scenarios</h1>
        <p className="muted">Thirteen scenarios cover the three parties the challenge names (Administrator, Organisation, AI system) plus the clinical flow. Each one shows who enforces it.</p>
      </div>
      <div className="card soft">
        <h3>Demo accounts (create these in the Tide console)</h3>
        <table>
          <thead><tr><th>Username</th><th>Realm role</th><th>Also</th></tr></thead>
          <tbody>
            <tr><td>admin</td><td>it_admin</td><td>tide-realm-admin (created by setup)</td></tr>
            <tr><td>director</td><td>hospital_director</td><td>tide-realm-admin</td></tr>
            <tr><td>compliance</td><td>compliance_officer</td><td>tide-realm-admin</td></tr>
            <tr><td>paramedic</td><td>paramedic</td><td></td></tr>
            <tr><td>drlee</td><td>doctor</td><td></td></tr>
            <tr><td>patient1</td><td>patient</td><td></td></tr>
            <tr><td>nok1</td><td>next_of_kin</td><td></td></tr>
          </tbody>
        </table>
      </div>
      {SCENARIOS.map((s) => (
        <div className="card section" key={s.id}>
          <div className="spread">
            <h2>{s.id} · {s.title}</h2>
            <div className="row">{s.enforcement.map((e) => <Tag key={e} kind={e} />)}<span className="badge b-role">{s.party}</span></div>
          </div>
          <div className="kv">
            <div>Actors</div><div>{s.actors}</div>
            <div>Where</div><div><code>{s.where}</code></div>
          </div>
          <ol className="small">{s.steps.map((x) => <li key={x}>{x}</li>)}</ol>
          <p className="small"><strong>Expected:</strong> {s.expected}</p>
          <p className="small"><strong style={{ color: '#c2b3ff' }}>Role of TideCloak:</strong> {s.tidecloak}</p>
        </div>
      ))}
    </Shell>
  )
}
