'use client'
import { useCallback, useEffect, useState } from 'react'
import { useParams } from 'next/navigation'
import Shell, { Tag, Msg } from '@/components/Shell'
import RequestCard from '@/components/RequestCard'
import { useAuth, api } from '@/lib/client/auth'
import { importKey, open, dec } from '@/lib/client/crypto'

type M = { kind: 'ok' | 'bad' | 'info'; text: string } | null

export default function CasePage() {
  const { id } = useParams<{ id: string }>()
  const auth = useAuth()
  const [data, setData] = useState<any>(null)
  const [reason, setReason] = useState('Patient in ED resus bay; need scene footage to guide treatment')
  const [msg, setMsg] = useState<M>(null)
  const [openMsg, setOpenMsg] = useState<M>(null)
  const [record, setRecord] = useState<any>(null)
  const [videoUrl, setVideoUrl] = useState('')
  const [integrity, setIntegrity] = useState<any>(null)
  const [finalP, setFinalP] = useState('P1 - Critical')

  const load = useCallback(async () => {
    const r = await api(auth, `/api/cases/${id}`)
    if (r.ok) setData(r.data)
    else setMsg({ kind: 'bad', text: r.data?.error || `HTTP ${r.status}` })
  }, [auth, id])

  useEffect(() => { if (auth.authenticated) load() }, [auth.authenticated, load])

  async function requestAccess(mode: string) {
    setMsg(null)
    const r = await api(auth, `/api/cases/${id}/requests`, { method: 'POST', body: JSON.stringify({ mode, reason }) })
    setMsg(r.ok ? { kind: 'info', text: `Request ${r.data.request.id} created. Nothing is released until every approval slot is filled by someone else.` } : { kind: 'bad', text: r.data?.error || `HTTP ${r.status}` })
    load()
  }

  async function approve(reqId: string, slot: number) {
    const r = await api(auth, `/api/requests/${reqId}/approve`, { method: 'POST', body: JSON.stringify({ slot }) })
    setMsg(r.ok ? { kind: 'ok', text: `Approval recorded (${r.data.request.status}).` } : { kind: 'bad', text: r.data?.error || `HTTP ${r.status}` })
    load()
  }
  async function deny(reqId: string) {
    const r = await api(auth, `/api/requests/${reqId}/deny`, { method: 'POST' })
    setMsg(r.ok ? { kind: 'ok', text: 'Request refused.' } : { kind: 'bad', text: r.data?.error || `HTTP ${r.status}` })
    load()
  }

  async function openRecord() {
    setOpenMsg({ kind: 'info', text: 'Asking the Key Release Service for the case key...' })
    const k = await api(auth, `/api/cases/${id}/key`)
    if (!k.ok) { setOpenMsg({ kind: 'bad', text: `${k.status} · ${k.data?.error}` }); return }
    try {
      const blob = await api(auth, `/api/cases/${id}/blob`)
      const key = await importKey(k.data.key)
      const details = JSON.parse(dec(await open(key, blob.data.details)))
      const vid = await open(key, blob.data.video)
      setRecord(details)
      setVideoUrl(URL.createObjectURL(new Blob([vid as BlobPart], { type: details.videoMime || 'video/webm' })))
      setOpenMsg({ kind: 'ok', text: `Decrypted in your browser. Access window ends ${new Date(k.data.grant.grantExpiresAt).toLocaleTimeString()}. This viewing is in the audit trail.` })
    } catch (e: any) {
      setOpenMsg({ kind: 'bad', text: `Decryption failed: the ciphertext does not match its key (record altered?). ${e?.message || ''}` })
    }
  }

  async function aiDecision(decision: 'confirmed' | 'overridden') {
    const r = await api(auth, `/api/cases/${id}/ai-decision`, { method: 'POST', body: JSON.stringify({ decision, finalPriority: decision === 'confirmed' ? record?.aiTriage?.priority : finalP }) })
    setOpenMsg(r.ok ? { kind: 'ok', text: `AI suggestion ${decision}. Recorded as a human decision.` } : { kind: 'bad', text: r.data?.error })
    load()
  }

  async function verify() {
    const r = await api(auth, `/api/cases/${id}/verify`)
    setIntegrity(r.data)
  }

  async function requestDeletion() {
    const r = await api(auth, `/api/cases/${id}/delete-request`, { method: 'POST', body: JSON.stringify({ reason: 'Board instruction: remove recording' }) })
    setMsg(r.ok ? { kind: 'info', text: `${r.data.message} (${r.data.request.id}: needs compliance officer + patient)` } : { kind: 'bad', text: r.data?.error || `HTTP ${r.status}` })
    load()
  }

  const c = data?.case
  const isDoctor = auth.roles.includes('doctor')
  const isOrg = auth.roles.includes('hospital_director') || auth.roles.includes('it_admin')

  return (
    <Shell>
      <div className="section spread"><h1>{id}</h1>{c && (c.status === 'sealed' ? <span className="badge b-ok">SEALED</span> : <span className="badge b-bad">CRYPTO-SHREDDED</span>)}</div>
      <Msg m={msg} />
      {c && (
        <div className="grid g2 section">
          <div className="card">
            <div className="spread"><h2>What the server knows</h2><Tag kind="app" /></div>
            <div className="kv">
              <div>Sealed at</div><div>{new Date(c.createdAt).toLocaleString()}</div>
              <div>Paramedic</div><div>{c.paramedic}</div>
              <div>Patient account</div><div>{c.patientUsername}</div>
              <div>Next of kin</div><div>{c.nokUsername}</div>
              <div>Incident</div><div>{c.incidentType}</div>
              <div>AI (advisory)</div><div>{c.aiPriority}</div>
              <div>Human decision</div><div>{c.aiDecision ? `${c.aiDecision.decision} by ${c.aiDecision.by} → ${c.aiDecision.finalPriority}` : <span className="badge b-warn">awaiting doctor</span>}</div>
              <div>Ciphertext</div><div>{c.blobBytes.toLocaleString()} bytes</div>
              <div>Sealed SHA-256</div><div className="mono" style={{ wordBreak: 'break-all' }}>{c.sealedHash}</div>
            </div>
            <div className="row" style={{ marginTop: 10 }}>
              <button className="small" onClick={verify}>Verify integrity</button>
              {integrity && (integrity.ok ? <span className="badge b-ok">{integrity.shredded ? 'shredded (expected)' : 'INTACT: hash matches seal'}</span> : <span className="badge b-bad">TAMPERED: hash mismatch, alert logged</span>)}
            </div>
          </div>

          <div className="card">
            <div className="spread"><h2>Open the record</h2><Tag kind="app" /></div>
            <p className="small muted">Anyone can press this. The server releases the case key only to a TideCloak-verified <code>doctor</code> whose own request has met its quorum. Try it as the admin or director.</p>
            <button className="primary" onClick={openRecord} disabled={c.status !== 'sealed'}>Open video &amp; patient details</button>
            <Msg m={openMsg} />
            {record && (
              <div style={{ marginTop: 10 }}>
                {videoUrl && <video src={videoUrl} controls autoPlay muted />}
                <div className="kv" style={{ marginTop: 8 }}>
                  <div>Patient</div><div>{record.patientName}</div>
                  <div>Address</div><div>{record.address}</div>
                  <div>Phone</div><div>{record.phone}</div>
                  <div>Incident</div><div>{record.incident}</div>
                  <div>Vitals</div><div>{record.vitals}</div>
                  <div>Field notes</div><div>{record.fieldNotes || '-'}</div>
                </div>
                {record.aiTriage && (
                  <div className="card soft" style={{ marginTop: 10 }}>
                    <div className="spread"><strong>AI suggestion: {record.aiTriage.priority}</strong><Tag kind="sim" /></div>
                    <ul className="small">{record.aiTriage.observations.map((o: string) => <li key={o}>{o}</li>)}</ul>
                    <div className="row">
                      <button className="ok small" onClick={() => aiDecision('confirmed')}>Confirm</button>
                      <select style={{ width: 170 }} value={finalP} onChange={(e) => setFinalP(e.target.value)}>
                        <option>P1 - Critical</option><option>P2 - Urgent</option><option>P3 - Non-urgent</option>
                      </select>
                      <button className="small" onClick={() => aiDecision('overridden')}>Override</button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {c && isDoctor && c.status === 'sealed' && (
        <div className="card section">
          <div className="spread"><h2>Request access (treating doctor)</h2><Tag kind="app" /></div>
          <label>Clinical reason (shown to approvers and kept in the audit trail)</label>
          <input value={reason} onChange={(e) => setReason(e.target.value)} />
          <div className="grid g3" style={{ marginTop: 10 }}>
            <div className="card soft"><h3>Patient consent</h3><p className="small muted">Patient is conscious. You + <strong>{c.patientUsername}</strong>. 60-min window.</p><button onClick={() => requestAccess('consent')}>Request</button></div>
            <div className="card soft"><h3>Next-of-kin proxy</h3><p className="small muted">Patient unconscious. You + <strong>{c.nokUsername}</strong>. 60-min window.</p><button onClick={() => requestAccess('proxy')}>Request</button></div>
            <div className="card soft" style={{ borderColor: 'var(--bad)' }}><h3>Break-glass</h3><p className="small muted">Nobody reachable. You + compliance officer + hospital director. 30-min window. Patient notified.</p><button className="danger" onClick={() => requestAccess('breakglass')}>Break glass</button></div>
          </div>
        </div>
      )}

      {c && isOrg && c.status === 'sealed' && (
        <div className="card section">
          <div className="spread"><h2>Organisation actions</h2><Tag kind="app" /></div>
          <p className="small muted">Try to delete this record as the director or IT admin. It will <strong>not</strong> be deleted: it becomes a request that needs the compliance officer and the patient.</p>
          <button className="danger" onClick={requestDeletion}>Delete this record</button>
        </div>
      )}

      {data && (
        <div className="section">
          <h2>Requests on this case</h2>
          {data.requests.length === 0 && <p className="muted">None yet.</p>}
          {data.requests.map((r: any) => <RequestCard key={r.id} r={r} showCase={false} onApprove={(s) => approve(r.id, s)} onDeny={() => deny(r.id)} />)}
        </div>
      )}
    </Shell>
  )
}
