'use client'
import { useEffect, useState } from 'react'
import Link from 'next/link'
import Shell, { Tag } from '@/components/Shell'
import { useAuth, api } from '@/lib/client/auth'

export default function Cases() {
  const auth = useAuth()
  const [cases, setCases] = useState<any[] | null>(null)
  const [err, setErr] = useState('')
  useEffect(() => {
    if (!auth.authenticated) return
    api(auth, '/api/cases').then((r) => (r.ok ? setCases(r.data.cases) : setErr(r.data?.error || String(r.status))))
  }, [auth.authenticated])

  return (
    <Shell>
      <div className="section spread"><h1>Case records</h1><Tag kind="app" /></div>
      <p className="muted">Everyone listed here sees the same non-identifying metadata. Patient identity, address, vitals and video are ciphertext until a quorum releases the key to one doctor.</p>
      {err && <div className="msg bad">{err}</div>}
      <div className="card">
        <table>
          <thead><tr><th>Case</th><th>Sealed</th><th>Paramedic</th><th>Patient acct</th><th>AI suggestion</th><th>Status</th><th>Your access</th></tr></thead>
          <tbody>
            {(cases || []).map((c) => (
              <tr key={c.id}>
                <td><Link href={`/cases/${c.id}`}>{c.id}</Link><div className="small muted">{c.incidentType}</div></td>
                <td className="small">{new Date(c.createdAt).toLocaleString()}</td>
                <td>{c.paramedic}</td>
                <td>{c.patientUsername}</td>
                <td className="small">{c.aiDecision ? <span className="badge b-ok">{c.aiDecision.decision} by {c.aiDecision.by}: {c.aiDecision.finalPriority}</span> : <span className="badge b-warn">{c.aiPriority}</span>}</td>
                <td>{c.status === 'sealed' ? <span className="badge b-ok">sealed</span> : <span className="badge b-bad">shredded</span>}</td>
                <td>{c.myActiveGrant ? <span className="badge b-ok">granted until {new Date(c.myActiveGrant.grantExpiresAt).toLocaleTimeString()}</span> : <span className="badge b-role">none</span>}</td>
              </tr>
            ))}
            {cases && cases.length === 0 && <tr><td colSpan={7} className="muted">No cases yet. A paramedic creates one under Dispatch &amp; capture.</td></tr>}
          </tbody>
        </table>
      </div>
    </Shell>
  )
}
