'use client'
import { Suspense, useEffect, useState } from 'react'
import { useSearchParams } from 'next/navigation'
import Link from 'next/link'
import Shell, { Tag, appRoles } from '@/components/Shell'
import { useAuth, api } from '@/lib/client/auth'

const ROLE_INFO: Record<string, { title: string; can: string; cannot: string; href: string; cta: string }> = {
  paramedic: { title: 'Paramedic', can: 'Take a dispatch, record the patient, run the on-device AI triage, seal the record.', cannot: 'Re-open a record after sealing it.', href: '/paramedic', cta: 'Open dispatch' },
  doctor: { title: 'Treating doctor', can: 'Request access to a record and view it once the quorum approves. Confirm or override the AI.', cannot: 'Open anything without approval, or approve your own request.', href: '/cases', cta: 'Case records' },
  patient: { title: 'Patient', can: 'Approve or deny doctors, see every access to your record, keep a Tide-encrypted personal vault.', cannot: '-', href: '/patient', cta: 'My records' },
  next_of_kin: { title: 'Next of kin', can: 'Give proxy consent when the patient is unconscious.', cannot: 'Read the record yourself.', href: '/approvals', cta: 'Approvals' },
  compliance_officer: { title: 'Compliance officer', can: 'Co-approve break-glass and deletions, inspect the audit chain.', cannot: 'Read patient data, or approve alone.', href: '/approvals', cta: 'Approvals' },
  hospital_director: { title: 'Hospital director', can: 'Co-approve break-glass, propose deletions.', cannot: 'Delete or alter a record alone, or read patient data.', href: '/approvals', cta: 'Approvals' },
  it_admin: { title: 'IT administrator', can: 'Operate the platform, inspect the raw DB (ciphertext), run the threat simulator.', cannot: 'Read patient data, or grant yourself roles (TideCloak QEA).', href: '/admin', cta: 'System console' },
}

export default function HomePage() {
  return <Suspense fallback={null}><Home /></Suspense>
}

function Home() {
  const auth = useAuth()
  const [me, setMe] = useState<any>(null)
  const [notes, setNotes] = useState<any[]>([])
  const denied = useSearchParams()?.get('denied')

  useEffect(() => {
    if (!auth.authenticated) return
    ;(async () => {
      const r = await api(auth, '/api/me')
      setMe(r.ok ? r.data : { error: r.data?.error || r.status })
      try {
        const k = `mq-signin-${auth.username}`
        if (!sessionStorage.getItem(k)) { sessionStorage.setItem(k, '1'); await api(auth, '/api/me', { method: 'POST' }) }
      } catch { /* ignore */ }
      const n = await api(auth, '/api/notifications')
      if (n.ok) setNotes(n.data.notifications)
    })()
  }, [auth.authenticated, auth.username])

  const roles = appRoles(auth.roles)
  return (
    <Shell>
      <div className="section spread">
        <div>
          <h1>Welcome, {auth.username}</h1>
          <p className="muted">Your identity and roles below are what the <strong>server</strong> accepted after verifying your TideCloak token.</p>
        </div>
        <Tag kind="real" />
      </div>

      {denied && <div className="msg bad" style={{ marginBottom: 12 }}>The TideCloak proxy blocked <code>{denied}</code> on the server: your signed token does not carry a role allowed on that page.</div>}
      <div className="card">
        {me?.error ? (
          <div className="msg bad">Server rejected the token: {String(me.error)}</div>
        ) : me ? (
          <div className="kv">
            <div>Username</div><div>{me.username}</div>
            <div>Subject (sub)</div><div className="mono">{me.sub}</div>
            <div>Verified by</div><div>{me.mode === 'tide' ? 'verifyTideCloakToken: realm key signature, issuer, azp, expiry' : 'MOCK header (no verification)'}</div>
            <div>App roles</div><div>{appRoles(me.roles).join(', ') || <span className="badge b-warn">none - ask the admins to grant one (needs QEA quorum in TideCloak)</span>}</div>
          </div>
        ) : 'Verifying with server...'}
      </div>

      {notes.length > 0 && (
        <div className="card section" style={{ borderColor: 'var(--warn)' }}>
          <h3>Notifications</h3>
          {notes.map((n) => <div key={n.id} className="small" style={{ padding: '4px 0' }}><span className="muted">{new Date(n.at).toLocaleString()}</span> · {n.text}</div>)}
        </div>
      )}

      <div className="grid g2 section">
        {roles.map((r) => {
          const i = ROLE_INFO[r]
          return (
            <div className="card" key={r}>
              <h2>{i.title}</h2>
              <p className="small"><strong className="muted">Can:</strong> {i.can}</p>
              <p className="small"><strong className="muted">Cannot:</strong> {i.cannot}</p>
              <Link href={i.href}><button className="primary">{i.cta}</button></Link>
            </div>
          )
        })}
        {roles.length === 0 && (
          <div className="card">
            <h2>No role assigned yet</h2>
            <p className="small muted">New Tide accounts start with no app role. An admin assigns one in the Tide console (People, then Roles). In this realm that change is a <strong>QEA change request</strong>: once there are 3 admins, 2 must authorize it before it takes effect. Sign out and back in after approval to refresh your token.</p>
          </div>
        )}
      </div>
    </Shell>
  )
}
