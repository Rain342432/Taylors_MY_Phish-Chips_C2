'use client'
import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Shell, { Tag } from '@/components/Shell'
import { useAuth, MOCK, CONFIGURED, TIDELESS, MOCK_PERSONAS } from '@/lib/client/auth'

export default function Landing() {
  const auth = useAuth()
  const router = useRouter()
  useEffect(() => {
    if (auth.authenticated) router.push('/home')
  }, [auth.authenticated, router])

  return (
    <Shell requireAuth={false}>
      <section className="hero">
        <span className="badge b-real">RMIT Hackathon 2026 · Challenge 2 · Build without blind trust</span>
        <h1 style={{ marginTop: 12 }}>Emergency records that no single party controls.</h1>
        <p className="muted" style={{ maxWidth: 760, fontSize: '1.05rem' }}>
          Paramedics record a patient on scene. The video and details are encrypted on the device and sealed.
          After that, <strong>no administrator, no hospital executive and no AI system</strong> can open, change or delete the
          record alone. Access needs a quorum of independent people, and every attempt lands in a tamper-evident audit trail.
        </p>
        <div className="row" style={{ marginTop: 18 }}>
          {!MOCK && CONFIGURED && (
            <button className="tide" onClick={() => auth.login()} disabled={!auth.ready}>
              {auth.ready ? (TIDELESS ? 'Sign in with TideCloak' : 'Sign in with Tide') : 'Connecting to TideCloak...'}
            </button>
          )}
          <a className="btn" href="/scenarios">View demo scenarios</a>
        </div>
        {TIDELESS && (
          <p className="small muted" style={{ marginTop: 8 }}>Demo users: admin, director, compliance, paramedic, drlee, patient1, nok1 · password <code>Medquorum1!</code></p>
        )}
        {!MOCK && !CONFIGURED && (
          <div className="msg bad">
            TideCloak is not configured: <code>app/tidecloak.json</code> is empty. Run <code>setup-tidecloak.ps1</code> from the project folder, then restart <code>npm run dev</code>.
          </div>
        )}
        {MOCK && (
          <div className="card" style={{ marginTop: 18 }}>
            <h3>Mock sign-in (UI testing only, no TideCloak)</h3>
            <div className="row">
              {MOCK_PERSONAS.map((p) => (
                <button key={p.username} onClick={() => auth.login(p.username)}>{p.label} <span className="muted small">({p.username})</span></button>
              ))}
            </div>
          </div>
        )}
      </section>

      <div className="grid g3 section">
        <div className="card">
          <h3>Administrator</h3>
          <p className="muted small">Runs the platform but cannot read patient data. Cannot grant himself the <code>doctor</code> role: TideCloak turns that into a change request that needs 2 of 3 admins.</p>
          <Tag kind="real" />
        </div>
        <div className="card">
          <h3>Organisation</h3>
          <p className="muted small">The hospital director cannot quietly delete or rewrite a record. Deletion needs the compliance officer and the patient. Edits are detected by sealed hashes and a hash-chained audit trail.</p>
          <Tag kind="app" />
        </div>
        <div className="card">
          <h3>AI system</h3>
          <p className="muted small">The organisation's on-device triage AI only suggests a priority. It cannot read stored records, and a doctor must confirm or override it.</p>
          <Tag kind="sim" /> <Tag kind="app" />
        </div>
      </div>

      <div className="card section soft">
        <h3>How to read the labels</h3>
        <div className="row small">
          <Tag kind="real" /> <span className="muted">enforced by TideCloak / the Tide Cybersecurity Fabric</span>
        </div>
        <div className="row small" style={{ marginTop: 6 }}>
          <Tag kind="app" /> <span className="muted">enforced by our server using identities and roles that TideCloak has verified</span>
        </div>
        <div className="row small" style={{ marginTop: 6 }}>
          <Tag kind="sim" /> <span className="muted">mocked for the prototype (AI triage, route map, attack simulator)</span>
        </div>
      </div>
    </Shell>
  )
}
