'use client'
import { useCallback, useEffect, useState } from 'react'
import Link from 'next/link'
import Shell, { Tag, Msg } from '@/components/Shell'
import { useAuth, api } from '@/lib/client/auth'

export default function Patient() {
  const auth = useAuth()
  const [cases, setCases] = useState<any[]>([])
  const [audit, setAudit] = useState<any[]>([])
  const [vaultText, setVaultText] = useState('Allergies: penicillin\nMedication: metformin 500mg\nConsent: allow break-glass only with compliance officer present')
  const [stored, setStored] = useState<any>(null)
  const [msg, setMsg] = useState<{ kind: 'ok' | 'bad' | 'info'; text: string } | null>(null)
  const [busy, setBusy] = useState(false)

  const load = useCallback(async () => {
    const [c, a, v] = await Promise.all([api(auth, '/api/cases'), api(auth, '/api/audit'), api(auth, '/api/vault')])
    if (c.ok) setCases(c.data.cases.filter((x: any) => x.patientUsername === auth.username || x.nokUsername === auth.username))
    if (a.ok) setAudit(a.data.entries.filter((e: any) => e.caseId))
    if (v.ok) setStored(v.data.vault)
  }, [auth])
  useEffect(() => { if (auth.authenticated) load() }, [auth.authenticated, load])

  async function saveVault() {
    setBusy(true); setMsg({ kind: 'info', text: 'Encrypting with TideCloak doEncrypt (tag "vault")...' })
    try {
      const ct = await auth.encrypt(vaultText, 'vault')
      const r = await api(auth, '/api/vault', { method: 'PUT', body: JSON.stringify({ ciphertext: ct }) })
      if (!r.ok) throw new Error(r.data?.error)
      setStored(r.data.vault)
      setMsg({ kind: 'ok', text: 'Saved. The server and the admins hold only the Tide ciphertext shown below.' })
    } catch (e: any) {
      setMsg({ kind: 'bad', text: `Tide encryption failed: ${e?.message || e}. Your token needs _tide_vault.selfencrypt (a default role in this realm).` })
    } finally { setBusy(false) }
  }

  async function loadVault() {
    if (!stored) return
    setBusy(true)
    try {
      setVaultText(await auth.decrypt(stored.ciphertext, 'vault'))
      setMsg({ kind: 'ok', text: 'Decrypted through the Tide Fabric for your session only.' })
    } catch (e: any) {
      setMsg({ kind: 'bad', text: `Tide decryption failed: ${e?.message || e}` })
    } finally { setBusy(false) }
  }

  return (
    <Shell>
      <div className="section"><h1>My records &amp; vault</h1></div>
      <div className="grid g2">
        <div className="card">
          <div className="spread"><h2>Personal health vault</h2><Tag kind="real" /></div>
          <p className="small muted">Encrypted with <strong>TideCloak E2EE</strong> (<code>doEncrypt</code>, tag <code>vault</code>). The key is never held by any one server; the Tide Fabric decrypts only for your authenticated session. Not even the IT admin can read it.</p>
          <textarea value={vaultText} onChange={(e) => setVaultText(e.target.value)} />
          <div className="row" style={{ marginTop: 8 }}>
            <button className="tide" onClick={saveVault} disabled={busy}>Encrypt &amp; save</button>
            <button onClick={loadVault} disabled={busy || !stored}>Load &amp; decrypt</button>
          </div>
          <Msg m={msg} />
          {stored && (
            <div style={{ marginTop: 10 }}>
              <div className="small muted">Stored on the server ({stored.mode === 'tide' ? 'Tide ciphertext' : 'MOCK, not encrypted'}), updated {new Date(stored.updatedAt).toLocaleString()}:</div>
              <div className="cipher">{stored.ciphertext.slice(0, 220)}…</div>
            </div>
          )}
        </div>
        <div className="card">
          <div className="spread"><h2>Records about me</h2><Tag kind="app" /></div>
          {cases.length === 0 && <p className="muted">No emergency records reference your account.</p>}
          {cases.map((c) => (
            <div key={c.id} className="slot">
              <span><Link href={`/cases/${c.id}`}>{c.id}</Link> <span className="small muted">{new Date(c.createdAt).toLocaleString()}</span></span>
              <span className={`badge ${c.status === 'sealed' ? 'b-ok' : 'b-bad'}`}>{c.status}</span>
            </div>
          ))}
          <p className="small muted" style={{ marginTop: 10 }}>Pending requests that need your consent are under <Link href="/approvals">Approvals</Link>.</p>
        </div>
      </div>

      <div className="card section">
        <div className="spread"><h2>Who touched my records</h2><span className="badge b-app">hash-chained audit</span></div>
        <table>
          <thead><tr><th>When</th><th>Who</th><th>Action</th><th>Result</th><th>Detail</th></tr></thead>
          <tbody>
            {audit.map((e) => (
              <tr key={e.seq}>
                <td className="small">{new Date(e.ts).toLocaleString()}</td>
                <td>{e.actor}</td>
                <td className="small">{e.action}</td>
                <td><span className={`badge ${e.outcome === 'OK' ? 'b-ok' : e.outcome === 'PENDING' ? 'b-warn' : 'b-bad'}`}>{e.outcome}</span></td>
                <td className="small">{e.detail}</td>
              </tr>
            ))}
            {audit.length === 0 && <tr><td colSpan={5} className="muted">No events yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </Shell>
  )
}
