// Server-side page protection with the TideCloak SDK (createTideCloakProxy).
// The SDK writes the access token to the `kcToken` cookie on login/refresh; this
// proxy verifies its signature/issuer/expiry against the realm and checks the
// role BEFORE the page is served. APIs are not routed here - every API route
// verifies the Bearer token itself with verifyTideCloakToken.
import type { NextRequest } from 'next/server'
import { NextResponse } from 'next/server'
import { createTideCloakProxy } from '@tidecloak/nextjs/server'
import type { TidecloakConfig } from '@tidecloak/nextjs/server'
import rawConfig from './tidecloak.json'

const tcConfig = rawConfig as TidecloakConfig
const ACTIVE = process.env.MEDQUORUM_MOCK_AUTH !== '1' && !!(rawConfig as Record<string, unknown>)['realm']

const STAFF = ['paramedic', 'doctor', 'compliance_officer', 'hospital_director', 'it_admin']

const tideProxy = createTideCloakProxy({
  config: tcConfig,
  protectedRoutes: {
    '/paramedic/*': ['paramedic'],
    '/admin/*': ['it_admin', 'compliance_officer'],
    '/governance/*': ['it_admin', 'hospital_director', 'compliance_officer'],
    '/cases/*': [...STAFF, 'patient', 'next_of_kin'],
  },
  onFailure: (_ctx: { token: string | null }, req: NextRequest) => {
    const url = new URL('/home', req.url)
    url.searchParams.set('denied', req.nextUrl.pathname)
    return NextResponse.redirect(url)
  },
  onError: (err: unknown, req: NextRequest) => {
    console.error('[MedQuorum proxy] verification error on', req.nextUrl.pathname, err)
    return NextResponse.redirect(new URL('/home', req.url))
  },
})

export async function proxy(req: NextRequest) {
  if (!ACTIVE) return NextResponse.next()
  return tideProxy(req)
}

export const config = {
  matcher: ['/paramedic', '/paramedic/:path*', '/admin', '/admin/:path*', '/governance', '/governance/:path*', '/cases', '/cases/:path*'],
}
