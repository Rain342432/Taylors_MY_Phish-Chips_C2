// Server-side identity. In normal mode EVERY API call must carry a TideCloak
// access token, which is verified with verifyTideCloakToken (signature against the
// realm's keys, issuer, azp, expiry). Roles come only from that signed token, so
// the app cannot "decide" someone is a doctor - TideCloak (under quorum governance)
// does.
//
// MOCK MODE (MEDQUORUM_MOCK_AUTH=1) exists only so the UI can be developed and
// tested without a TideCloak server. It is clearly bannered in the UI and is OFF
// by default. Never use it for the demo of trust properties.
import { NextRequest, NextResponse } from 'next/server'
import { verifyTideCloakToken } from '@tidecloak/nextjs/server'
import tcConfig from '../../tidecloak.json'

export const MOCK = process.env.MEDQUORUM_MOCK_AUTH === '1'

export const MOCK_USERS: Record<string, string[]> = {
  admin: ['it_admin'],
  director: ['hospital_director'],
  compliance: ['compliance_officer'],
  paramedic: ['paramedic'],
  drlee: ['doctor'],
  patient1: ['patient'],
  nok1: ['next_of_kin'],
}

export type User = { username: string; sub: string; roles: string[]; mode: 'tide' | 'mock' }

export async function getUser(req: NextRequest): Promise<User | null> {
  if (MOCK) {
    const u = req.headers.get('x-mock-user') || ''
    if (!MOCK_USERS[u]) return null
    return { username: u, sub: `mock-${u}`, roles: MOCK_USERS[u], mode: 'mock' }
  }
  const h = req.headers.get('authorization') || ''
  if (!h.startsWith('Bearer ')) return null
  const cfg = tcConfig as Record<string, unknown>
  if (!cfg || !cfg['realm']) return null
  const payload = (await verifyTideCloakToken(cfg as any, h.slice(7), [])) as Record<string, any> | null
  if (!payload) return null
  const realmRoles: string[] = payload.realm_access?.roles || []
  const clientRoles: string[] = payload.resource_access?.[cfg['resource'] as string]?.roles || []
  return {
    username: String(payload.preferred_username || payload.sub),
    sub: String(payload.sub),
    roles: [...new Set([...realmRoles, ...clientRoles])],
    mode: 'tide',
  }
}

export function has(u: User, role: string) {
  return u.roles.includes(role)
}

export function unauthorized() {
  return NextResponse.json({ error: 'Not signed in: a valid TideCloak access token is required.' }, { status: 401 })
}

export function forbidden(msg: string, extra: Record<string, unknown> = {}) {
  return NextResponse.json({ error: msg, ...extra }, { status: 403 })
}

export const APP_ROLES = ['paramedic', 'doctor', 'compliance_officer', 'hospital_director', 'it_admin', 'patient', 'next_of_kin']
