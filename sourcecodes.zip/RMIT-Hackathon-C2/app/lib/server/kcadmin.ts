// Thin pass-through to TideCloak's admin REST API using the CALLER's own token.
// MedQuorum holds no admin credentials: TideCloak decides whether the caller may
// act, and QEA turns governed writes (role grants) into change requests.
import tcConfig from '../../tidecloak.json'

const cfg = tcConfig as Record<string, any>
export const KC_BASE = String(cfg['auth-server-url'] || 'http://localhost:8080/').replace(/\/$/, '')
export const REALM = String(cfg.realm || '')

export async function kc(token: string, path: string, init: RequestInit = {}) {
  const res = await fetch(`${KC_BASE}/admin/realms/${REALM}${path}`, {
    ...init,
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', ...(init.headers as Record<string, string> || {}) },
    cache: 'no-store',
  })
  const text = await res.text()
  let body: any = text
  try { body = text ? JSON.parse(text) : null } catch { /* keep text */ }
  return { status: res.status, body }
}

export function bearer(h: string | null) {
  return h && h.startsWith('Bearer ') ? h.slice(7) : ''
}
