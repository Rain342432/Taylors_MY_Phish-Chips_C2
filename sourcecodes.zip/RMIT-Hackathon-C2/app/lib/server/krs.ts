// Key Release Service (KRS) - APP-LAYER STAND-IN, clearly simulated.
//
// Each case is encrypted in the paramedic's browser with a fresh AES-256-GCM key.
// That key is escrowed here, wrapped under a KRS master key, and is released ONLY
// to a TideCloak-verified doctor whose access request has met its quorum.
//
// Honest limitation: whoever runs this server process could read the master key.
// Production path: wrap the case key with Tide's threshold encryption under a
// Forseti decryption policy (doEncrypt(..., decryption_policy)), so the key is
// only ever reconstituted by the Tide Fabric (ORK nodes) after the quorum signs,
// and no server - ours included - ever holds it.
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { KRS_DIR } from './store'

function masterKey(): Buffer {
  fs.mkdirSync(KRS_DIR, { recursive: true })
  if (process.env.KRS_MASTER_KEY) return Buffer.from(process.env.KRS_MASTER_KEY, 'base64')
  const f = path.join(KRS_DIR, 'master.key')
  if (!fs.existsSync(f)) fs.writeFileSync(f, crypto.randomBytes(32).toString('base64'))
  return Buffer.from(fs.readFileSync(f, 'utf8'), 'base64')
}

export function escrowKey(caseId: string, rawKeyB64: string) {
  const iv = crypto.randomBytes(12)
  const c = crypto.createCipheriv('aes-256-gcm', masterKey(), iv)
  const ct = Buffer.concat([c.update(Buffer.from(rawKeyB64, 'base64')), c.final()])
  const tag = c.getAuthTag()
  fs.writeFileSync(path.join(KRS_DIR, `${caseId}.key`), JSON.stringify({ iv: iv.toString('base64'), ct: ct.toString('base64'), tag: tag.toString('base64') }))
}

export function releaseKey(caseId: string): string | null {
  const f = path.join(KRS_DIR, `${caseId}.key`)
  if (!fs.existsSync(f)) return null
  const w = JSON.parse(fs.readFileSync(f, 'utf8'))
  const d = crypto.createDecipheriv('aes-256-gcm', masterKey(), Buffer.from(w.iv, 'base64'))
  d.setAuthTag(Buffer.from(w.tag, 'base64'))
  return Buffer.concat([d.update(Buffer.from(w.ct, 'base64')), d.final()]).toString('base64')
}

export function wrappedKeyPreview(caseId: string): string | null {
  const f = path.join(KRS_DIR, `${caseId}.key`)
  if (!fs.existsSync(f)) return null
  return JSON.parse(fs.readFileSync(f, 'utf8')).ct
}

export function shredKey(caseId: string) {
  const f = path.join(KRS_DIR, `${caseId}.key`)
  if (fs.existsSync(f)) {
    fs.writeFileSync(f, crypto.randomBytes(64)) // overwrite, then remove
    fs.rmSync(f)
  }
}
