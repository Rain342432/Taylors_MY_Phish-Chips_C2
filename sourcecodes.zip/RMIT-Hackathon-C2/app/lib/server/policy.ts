// Multi-party access policies. A request is granted only when EVERY slot is filled
// by a distinct, TideCloak-verified person holding the slot's role (and, where set,
// being the exact person - the patient or their registered next of kin).
// The requester can never fill a slot on their own request.
import { AccessRequest, CaseRecord, Slot } from './store'
import { User } from './auth'

export const POLICIES = {
  consent: {
    title: 'Patient consent',
    when: 'Patient is conscious and can consent',
    grantMinutes: 60,
    slots: (c: CaseRecord): Slot[] => [{ label: 'Patient consent', role: 'patient', user: c.patientUsername }],
  },
  proxy: {
    title: 'Next-of-kin proxy consent',
    when: 'Patient is unconscious; registered next of kin is reachable',
    grantMinutes: 60,
    slots: (c: CaseRecord): Slot[] => [{ label: 'Next-of-kin consent', role: 'next_of_kin', user: c.nokUsername }],
  },
  breakglass: {
    title: 'Break-glass emergency access',
    when: 'Patient unconscious and nobody reachable',
    grantMinutes: 30,
    slots: (_c: CaseRecord): Slot[] => [
      { label: 'Compliance officer (independent)', role: 'compliance_officer' },
      { label: 'Hospital director (organisation)', role: 'hospital_director' },
    ],
  },
  deletion: {
    title: 'Record deletion / crypto-shred',
    when: 'Organisation wants to erase a record',
    grantMinutes: 0,
    slots: (c: CaseRecord): Slot[] => [
      { label: 'Compliance officer', role: 'compliance_officer' },
      { label: 'Patient (data owner)', role: 'patient', user: c.patientUsername },
    ],
  },
} as const

export type Mode = keyof typeof POLICIES

export function canFillSlot(u: User, req: AccessRequest, slot: Slot): { ok: boolean; why?: string } {
  if (slot.approvedBy) return { ok: false, why: 'slot already approved' }
  if (u.username === req.requester) return { ok: false, why: 'self-approval is forbidden: the requester cannot approve their own request' }
  if (req.slots.some((s) => s.approvedBy === u.username)) return { ok: false, why: 'one person can fill only one approval slot' }
  if (!u.roles.includes(slot.role)) return { ok: false, why: `requires TideCloak role '${slot.role}'` }
  if (slot.user && slot.user !== u.username) return { ok: false, why: `only '${slot.user}' may approve this slot` }
  return { ok: true }
}

export function refreshStatus(r: AccessRequest, now = Date.now()) {
  if (r.status === 'pending' && now > Date.parse(r.pendingExpiresAt)) r.status = 'expired'
  return r
}

export function grantActive(r: AccessRequest, now = Date.now()) {
  return r.kind === 'access' && r.status === 'approved' && !!r.grantExpiresAt && now < Date.parse(r.grantExpiresAt)
}
