// Minimal JSON-file data store for the prototype.
// Everything sensitive inside it is CIPHERTEXT: the server never sees patient
// details, video or vault contents in plaintext.
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'

export const DATA_DIR = process.env.MEDQUORUM_DATA_DIR || path.join(process.cwd(), 'data')
export const BLOB_DIR = path.join(DATA_DIR, 'blobs')
export const KRS_DIR = path.join(DATA_DIR, 'krs')
const DB_FILE = path.join(DATA_DIR, 'db.json')

export type Slot = {
  label: string
  role: string
  user?: string            // when set, only this exact username may fill the slot
  approvedBy?: string
  at?: string
}

export type AccessRequest = {
  id: string
  kind: 'access' | 'deletion'
  caseId: string
  requester: string
  requesterRoles: string[]
  mode: 'consent' | 'proxy' | 'breakglass' | 'deletion'
  reason: string
  createdAt: string
  pendingExpiresAt: string
  slots: Slot[]
  status: 'pending' | 'approved' | 'denied' | 'expired' | 'executed'
  deniedBy?: string
  grantExpiresAt?: string
}

export type CaseRecord = {
  id: string
  createdAt: string
  paramedic: string
  patientUsername: string
  nokUsername: string
  incidentType: string
  aiPriority: string                 // advisory label only, e.g. "P1 (AI suggestion, unconfirmed)"
  aiDecision?: { by: string; decision: 'confirmed' | 'overridden'; finalPriority: string; at: string }
  sealedHash: string                 // SHA-256 of the ciphertext blob at sealing time
  blobBytes: number
  status: 'sealed' | 'shredded'
}

export type Notification = { id: string; to: string; at: string; text: string }

export type Vault = { username: string; ciphertext: string; updatedAt: string; mode: 'tide' | 'mock' }

export type AuditEntry = {
  seq: number
  ts: string
  actor: string
  actorRoles: string[]
  action: string
  outcome: 'OK' | 'DENIED' | 'PENDING' | 'ALERT'
  caseId?: string
  detail: string
  prevHash: string
  hash: string
}

export type DB = {
  cases: CaseRecord[]
  requests: AccessRequest[]
  notifications: Notification[]
  vaults: Vault[]
  audit: AuditEntry[]
}

function empty(): DB {
  return { cases: [], requests: [], notifications: [], vaults: [], audit: [] }
}

function ensureDirs() {
  for (const d of [DATA_DIR, BLOB_DIR, KRS_DIR]) fs.mkdirSync(d, { recursive: true })
}

export function readDB(): DB {
  ensureDirs()
  if (!fs.existsSync(DB_FILE)) return empty()
  try {
    return { ...empty(), ...JSON.parse(fs.readFileSync(DB_FILE, 'utf8')) }
  } catch {
    return empty()
  }
}

export function writeDB(db: DB) {
  ensureDirs()
  const tmp = DB_FILE + '.tmp'
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2))
  fs.renameSync(tmp, DB_FILE)
}

// Serialise all mutations (single Node process in the prototype).
let chain: Promise<unknown> = Promise.resolve()
export function mutate<T>(fn: (db: DB) => T | Promise<T>): Promise<T> {
  const run = chain.then(async () => {
    const db = readDB()
    const out = await fn(db)
    writeDB(db)
    return out
  })
  chain = run.catch(() => undefined)
  return run
}

export function newId(prefix: string) {
  return `${prefix}-${crypto.randomBytes(4).toString('hex')}`
}

export function sha256(data: Buffer | string) {
  return crypto.createHash('sha256').update(data).digest('hex')
}

export function nowIso() {
  return new Date().toISOString()
}
