// Append-only, hash-chained audit log. Every entry commits to the previous one,
// so editing or deleting any past entry breaks the chain and is detected.
import { AuditEntry, DB, nowIso, sha256 } from './store'

const GENESIS = '0'.repeat(64)

function entryHash(e: Omit<AuditEntry, 'hash'>) {
  return sha256(JSON.stringify([e.seq, e.ts, e.actor, e.actorRoles, e.action, e.outcome, e.caseId ?? '', e.detail, e.prevHash]))
}

export function appendAudit(
  db: DB,
  a: { actor: string; actorRoles: string[]; action: string; outcome: AuditEntry['outcome']; caseId?: string; detail: string },
) {
  const prev = db.audit[db.audit.length - 1]
  const base = {
    seq: prev ? prev.seq + 1 : 1,
    ts: nowIso(),
    actor: a.actor,
    actorRoles: a.actorRoles.filter((r) => !r.startsWith('_tide_') && !r.startsWith('default-roles') && r !== 'offline_access' && r !== 'uma_authorization' && r !== 'appUser'),
    action: a.action,
    outcome: a.outcome,
    caseId: a.caseId,
    detail: a.detail,
    prevHash: prev ? prev.hash : GENESIS,
  }
  const entry: AuditEntry = { ...base, hash: entryHash(base) }
  db.audit.push(entry)
  return entry
}

export function verifyAudit(entries: AuditEntry[]) {
  let prevHash = GENESIS
  for (const e of entries) {
    const { hash, ...rest } = e
    if (e.prevHash !== prevHash) return { ok: false, brokenAt: e.seq, reason: 'prevHash does not link to the previous entry' }
    if (entryHash(rest) !== hash) return { ok: false, brokenAt: e.seq, reason: 'entry content was modified after it was written' }
    prevHash = hash
  }
  return { ok: true, entries: entries.length, head: prevHash }
}
