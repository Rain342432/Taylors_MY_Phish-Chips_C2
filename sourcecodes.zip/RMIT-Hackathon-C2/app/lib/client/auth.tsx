'use client'
// One auth interface for the whole UI.
//  - Normal mode: TideCloak (Tide BYOiD login, signed tokens, Tide E2EE doEncrypt/doDecrypt).
//  - Mock mode (NEXT_PUBLIC_MEDQUORUM_MOCK_AUTH=1): UI development only, loudly bannered.
import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { TideCloakProvider, useTideCloak } from '@tidecloak/nextjs'
import tcConfig from '../../tidecloak.json'

export const MOCK = process.env.NEXT_PUBLIC_MEDQUORUM_MOCK_AUTH === '1'
export const CONFIGURED = !!(tcConfig as Record<string, unknown>)['realm']
// Fallback when the Tide licence step fails: TideCloak QEA on a plain realm (password login, no Tide Fabric).
export const TIDELESS = (tcConfig as Record<string, unknown>)['medquorumMode'] === 'tideless'

export const MOCK_PERSONAS: { username: string; role: string; label: string }[] = [
  { username: 'paramedic', role: 'paramedic', label: 'Paramedic' },
  { username: 'drlee', role: 'doctor', label: 'Treating doctor' },
  { username: 'patient1', role: 'patient', label: 'Patient' },
  { username: 'nok1', role: 'next_of_kin', label: 'Next of kin' },
  { username: 'compliance', role: 'compliance_officer', label: 'Compliance officer' },
  { username: 'director', role: 'hospital_director', label: 'Hospital director' },
  { username: 'admin', role: 'it_admin', label: 'IT administrator' },
]

export type Auth = {
  mode: 'tide' | 'mock'
  ready: boolean
  authenticated: boolean
  username: string
  roles: string[]
  login: (persona?: string) => void
  logout: () => void
  authHeaders: () => Promise<Record<string, string>>
  encrypt: (data: string, tag: string) => Promise<string>
  decrypt: (ct: string, tag: string) => Promise<string>
  refresh: () => Promise<void>
}

const Ctx = createContext<Auth | null>(null)
export function useAuth() {
  const a = useContext(Ctx)
  if (!a) throw new Error('useAuth outside AuthProvider')
  return a
}

function decodeJwt(t?: string | null): Record<string, any> {
  if (!t) return {}
  try {
    const p = t.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')
    return JSON.parse(decodeURIComponent(escape(atob(p))))
  } catch {
    return {}
  }
}

function TideBridge({ children }: { children: ReactNode }) {
  const tc = useTideCloak() as any
  const payload = decodeJwt(tc.token)
  const roles: string[] = [
    ...(payload.realm_access?.roles || []),
    ...((payload.resource_access?.[(tcConfig as any).resource]?.roles as string[]) || []),
  ]
  const value: Auth = {
    mode: 'tide',
    ready: !tc.isInitializing,
    authenticated: !!tc.authenticated,
    username: payload.preferred_username || '',
    roles,
    login: () => tc.login(),
    logout: () => tc.logout(),
    authHeaders: async () => {
      try { await tc.refreshToken?.() } catch { /* auto-refresh handles it */ }
      return { Authorization: `Bearer ${tc.token}` }
    },
    // Real Tide E2EE: data is encrypted through the Tide Cybersecurity Fabric,
    // bound to this user's identity. Requires roles _tide_<tag>.selfencrypt / .selfdecrypt.
    encrypt: async (data, tag) => {
      if (TIDELESS) throw new Error('Tide E2EE needs the Tide Cybersecurity Fabric, which is unavailable in Tideless mode (Tide licence service failed during the event)')
      return (await tc.doEncrypt([{ data, tags: [tag] }]))[0]
    },
    decrypt: async (ct, tag) => {
      if (TIDELESS) throw new Error('Tide E2EE unavailable in Tideless mode')
      return String((await tc.doDecrypt([{ encrypted: ct, tags: [tag] }]))[0])
    },
    refresh: async () => { await tc.refreshToken?.() },
  }
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

function MockBridge({ children }: { children: ReactNode }) {
  const [user, setUser] = useState('')
  const [ready, setReady] = useState(false)
  useEffect(() => {
    try { setUser(sessionStorage.getItem('mq-mock-user') || '') } catch { /* ignore */ }
    setReady(true)
  }, [])
  const value = useMemo<Auth>(() => ({
    mode: 'mock',
    ready,
    authenticated: !!user,
    username: user,
    roles: MOCK_PERSONAS.filter((p) => p.username === user).map((p) => p.role),
    login: (persona?: string) => {
      if (!persona) return
      try { sessionStorage.setItem('mq-mock-user', persona) } catch { /* ignore */ }
      setUser(persona)
    },
    logout: () => {
      try { sessionStorage.removeItem('mq-mock-user') } catch { /* ignore */ }
      setUser('')
      window.location.href = '/'
    },
    authHeaders: async () => ({ 'x-mock-user': user }),
    encrypt: async (data, tag) => `MOCK-NOT-ENCRYPTED:${tag}:${btoa(unescape(encodeURIComponent(data)))}`,
    decrypt: async (ct) => decodeURIComponent(escape(atob(ct.split(':').slice(2).join(':')))),
    refresh: async () => {},
  }), [user, ready])
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

export function AuthProvider({ children }: { children: ReactNode }) {
  if (MOCK) return <MockBridge>{children}</MockBridge>
  if (!CONFIGURED) {
    const value: Auth = {
      mode: 'tide', ready: true, authenticated: false, username: '', roles: [],
      login: () => {}, logout: () => {}, authHeaders: async () => ({}),
      encrypt: async () => { throw new Error('TideCloak not configured') },
      decrypt: async () => { throw new Error('TideCloak not configured') },
      refresh: async () => {},
    }
    return <Ctx.Provider value={value}>{children}</Ctx.Provider>
  }
  return (
    <TideCloakProvider config={tcConfig as any}>
      <TideBridge>{children}</TideBridge>
    </TideCloakProvider>
  )
}

export async function api<T = any>(auth: Auth, url: string, init: RequestInit = {}): Promise<{ ok: boolean; status: number; data: T }> {
  const headers = { 'content-type': 'application/json', ...(await auth.authHeaders()), ...(init.headers as Record<string, string> || {}) }
  const res = await fetch(url, { ...init, headers })
  let data: any = null
  try { data = await res.json() } catch { data = null }
  return { ok: res.ok, status: res.status, data }
}
