'use client'
// Device-side encryption of the case record (AES-256-GCM via WebCrypto).
// Plaintext never leaves the paramedic's / doctor's browser.

export function b64(buf: ArrayBuffer | Uint8Array) {
  const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf)
  let s = ''
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode(...bytes.subarray(i, i + 0x8000))
  return btoa(s)
}

export function unb64(s: string) {
  const bin = atob(s)
  const out = new Uint8Array(bin.length)
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i)
  return out
}

export async function newCaseKey() {
  const key = await crypto.subtle.generateKey({ name: 'AES-GCM', length: 256 }, true, ['encrypt', 'decrypt'])
  const raw = await crypto.subtle.exportKey('raw', key)
  return { key, rawB64: b64(raw) }
}

export async function importKey(rawB64: string) {
  return crypto.subtle.importKey('raw', unb64(rawB64), { name: 'AES-GCM' }, false, ['decrypt'])
}

export async function seal(key: CryptoKey, data: Uint8Array) {
  const iv = crypto.getRandomValues(new Uint8Array(12))
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, data)
  return { iv: b64(iv), ct: b64(ct) }
}

export async function open(key: CryptoKey, box: { iv: string; ct: string }) {
  return new Uint8Array(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(box.iv) }, key, unb64(box.ct)))
}

export const enc = (s: string) => new TextEncoder().encode(s)
export const dec = (b: Uint8Array) => new TextDecoder().decode(b)
