// SIMULATED on-device AI triage. Represents an organisation-owned model that runs
// locally on the paramedic's device. No external AI API is called, so no patient
// data leaves the device for the AI. Output is canned and ADVISORY ONLY.
export type Triage = {
  model: string
  priority: 'P1 - Critical' | 'P2 - Urgent' | 'P3 - Non-urgent'
  confidence: number
  observations: string[]
  disclaimer: string
}

export async function runLocalTriage(incident: string): Promise<Triage> {
  await new Promise((r) => setTimeout(r, 1200))
  const chest = /chest|cardiac/i.test(incident)
  const unresp = /unrespons|unconscious|fall/i.test(incident)
  return {
    model: 'MedQuorum-LocalTriage v0.1 (SIMULATED, on-device)',
    priority: chest || unresp ? 'P1 - Critical' : 'P2 - Urgent',
    confidence: chest ? 0.81 : unresp ? 0.74 : 0.62,
    observations: chest
      ? ['Patient clutching chest, visible diaphoresis', 'Laboured breathing pattern', 'Skin pallor detected']
      : unresp
        ? ['No visible voluntary movement', 'Possible head contact with floor', 'Breathing present, shallow']
        : ['Patient alert and seated', 'No obvious distress markers'],
    disclaimer: 'Advisory only. Not a diagnosis. A doctor must confirm or override.',
  }
}
