export type Scenario = {
  id: string
  title: string
  party: 'Administrator' | 'Organisation' | 'AI system' | 'Clinical flow' | 'Patient'
  enforcement: ('real' | 'app' | 'sim')[]
  actors: string
  steps: string[]
  expected: string
  tidecloak: string
  where: string
}

export const SCENARIOS: Scenario[] = [
  {
    id: 'S1', title: 'Every user proves who they are with Tide', party: 'Clinical flow', enforcement: ['real'],
    actors: 'Any user', where: '/ → Sign in with Tide → /home',
    steps: ['Click "Sign in with Tide".', 'Authenticate in the Tide enclave.', 'Dashboard shows the identity and roles the SERVER verified.'],
    expected: 'The server accepts the user only after verifyTideCloakToken checks the realm signature, issuer, azp and expiry. Roles come only from the signed token.',
    tidecloak: 'Tide BYOiD login: no password database in MedQuorum, and no single server holds the user\'s key. TideCloak issues the signed token.',
  },
  {
    id: 'S2', title: 'Paramedic dispatch & route', party: 'Clinical flow', enforcement: ['real', 'sim'],
    actors: 'paramedic', where: '/paramedic (steps 1–2)',
    steps: ['Pick an incoming call.', 'See the patient address and the simulated fastest route and ETA.'],
    expected: 'Only a token with the paramedic role reaches this screen and the create-case API.',
    tidecloak: 'Role-based access from TideCloak-signed tokens. The route map is simulated so the address is never sent to a third-party map API.',
  },
  {
    id: 'S3', title: 'Record on scene and seal on the device', party: 'Clinical flow', enforcement: ['app'],
    actors: 'paramedic', where: '/paramedic (steps 3–5)',
    steps: ['Record 6 s from the webcam (or generate a test clip).', 'Add vitals and notes.', 'Encrypt, seal & upload.'],
    expected: 'Browser encrypts with a fresh AES-256-GCM key. The server stores only ciphertext plus its SHA-256 seal. The paramedic cannot re-open the record.',
    tidecloak: 'Only TideCloak-verified paramedics can create records. Production: the case key is wrapped by Tide threshold encryption instead of the simulated KRS.',
  },
  {
    id: 'S4', title: 'On-device AI suggests, a human decides', party: 'AI system', enforcement: ['sim', 'app'],
    actors: 'paramedic, doctor', where: '/paramedic step 4 → /cases/[id] (after access)',
    steps: ['Run local triage (canned output).', 'Suggestion is sealed with the record as "unconfirmed".', 'A doctor with an approved grant confirms or overrides it.'],
    expected: 'The AI never makes the decision. Its suggestion is advisory until a human doctor records a decision, and both are in the audit trail.',
    tidecloak: 'Only a doctor (TideCloak role) with an active quorum grant may confirm or override.',
  },
  {
    id: 'S5', title: 'Normal access: patient + doctor', party: 'Patient', enforcement: ['app', 'real'],
    actors: 'doctor (drlee), patient (patient1)', where: '/cases/[id] → Request (Patient consent) → patient /approvals',
    steps: ['Doctor requests access with a reason.', 'Doctor tries to open: DENIED (quorum not met).', 'Patient signs in and approves.', 'Doctor opens: video and details decrypt in the browser for 60 min.'],
    expected: 'The key is released only after the patient\'s approval. The doctor cannot approve their own request.',
    tidecloak: 'Each approval is bound to a TideCloak-verified identity (sub + preferred_username in a signed token), so approvals cannot be forged.',
  },
  {
    id: 'S6', title: 'Patient unconscious: next-of-kin proxy', party: 'Patient', enforcement: ['app', 'real'],
    actors: 'doctor, next_of_kin (nok1)', where: '/cases/[id] → Request (Next-of-kin proxy)',
    steps: ['Doctor requests proxy access.', 'Only the registered NoK account can fill the slot. The patient account or anyone else is rejected.', 'NoK approves, and the doctor gets 60 min.'],
    expected: 'The proxy slot is pinned to the exact registered person.',
    tidecloak: 'Identity is proven by Tide, so a different user cannot impersonate the next of kin.',
  },
  {
    id: 'S7', title: 'Nobody reachable: break-glass', party: 'Clinical flow', enforcement: ['app', 'real'],
    actors: 'doctor, compliance_officer, hospital_director', where: '/cases/[id] → Break glass',
    steps: ['Doctor breaks glass with a reason.', 'Patient and NoK are notified immediately.', 'Compliance officer AND hospital director must both approve.', 'Access lasts 30 min, then the key is no longer released.'],
    expected: 'Even in an emergency, three independent people are involved. The window is short and fully visible to the patient.',
    tidecloak: 'Approver roles are realm roles that can only be granted through quorum-approved change requests.',
  },
  {
    id: 'S8', title: 'Administrator tries to read patient data', party: 'Administrator', enforcement: ['app', 'real'],
    actors: 'it_admin', where: '/admin → "Open record as admin" / "Self-grant break-glass"',
    steps: ['Admin opens a record: 403 DENIED.', 'Admin tries to start break-glass: 403 DENIED.', 'Raw DB view shows ciphertext only.'],
    expected: 'Operating the system gives no data access. Every attempt is logged.',
    tidecloak: 'The admin\'s token, signed by TideCloak, has no doctor role. See S9 for why he can\'t simply add it.',
  },
  {
    id: 'S9', title: 'Administrator tries to grant himself the doctor role', party: 'Administrator', enforcement: ['real'],
    actors: 'it_admin, hospital_director, compliance_officer (all tide-realm-admin)', where: 'Tide console → People → Roles → QEA Approvals',
    steps: ['Admin assigns himself the doctor role.', 'TideCloak returns 202 and parks a change request.', 'With 3 admins, 2 approvals are needed (max(1, ⌊0.7N⌋)).', 'Only after another admin authorizes in their Tide enclave does the role exist in tokens.'],
    expected: 'No single administrator can escalate privileges. Every proposal and vote is logged by TideCloak.',
    tidecloak: 'Quorum-Enforced Authorization: the change is signed by the Tide Fabric with threshold signatures only once the quorum is met.',
  },
  {
    id: 'S10', title: 'Organisation tries to delete or alter a record', party: 'Organisation', enforcement: ['app'],
    actors: 'hospital_director → compliance_officer + patient', where: '/cases/[id] → "Delete this record"; /admin → "Insider edits stored record"',
    steps: ['Director clicks delete: it is NOT executed, only parked as a request.', 'Compliance officer and the patient must both approve, then the key is crypto-shredded and the history kept.', 'Insider edits the stored file directly, and "Verify integrity" flags the hash mismatch.'],
    expected: 'The organisation cannot erase or silently rewrite evidence.',
    tidecloak: 'All approvers are TideCloak-verified. Production: deletion maps to a Tide policy so the key can only be destroyed with quorum.',
  },
  {
    id: 'S11', title: 'AI service tries to harvest recordings', party: 'AI system', enforcement: ['sim', 'app'],
    actors: 'ai-triage-local (service)', where: '/admin → "AI service bulk-reads recordings"',
    steps: ['The organisation\'s AI asks for every case key ("for training").', 'Every request is DENIED and logged.'],
    expected: 'The AI has no human Tide identity and no quorum grant, so it can suggest but never read stored data.',
    tidecloak: 'Only Tide-authenticated humans with quorum grants receive keys.',
  },
  {
    id: 'S12', title: 'Tamper-evident audit trail', party: 'Organisation', enforcement: ['app'],
    actors: 'compliance_officer, patient', where: '/audit, /patient',
    steps: ['Every action (including denials) is appended with prevHash → hash.', 'Insider rewrites one entry (simulator).', 'Chain check pinpoints the broken entry. Restore makes it valid again.'],
    expected: 'History cannot be quietly rewritten. Patients see everyone who touched their record.',
    tidecloak: 'Actors in the log are TideCloak-verified identities. QEA keeps its own signed log of governance changes.',
  },
  {
    id: 'S13', title: 'Patient\'s personal vault (Tide E2EE)', party: 'Patient', enforcement: ['real'],
    actors: 'patient', where: '/patient → Personal health vault',
    steps: ['Patient types allergies and consent preferences.', 'Encrypt & save calls TideCloak doEncrypt (tag "vault").', 'Admin\'s raw DB view shows only ciphertext.', 'Load & decrypt works only in the patient\'s session.'],
    expected: 'Data the server cannot read, with no key held by MedQuorum or any single node.',
    tidecloak: 'Tide Hermetic E2EE: ORK nodes each hold a key fragment. No node ever holds a full key, and decryption is re-encrypted to the user\'s session.',
  },
]
