# MedQuorum: System Specification

**RMIT Hackathon 2026, Challenge 2: "Build without blind trust" (Vibe coding with TideCloak)**
Version 1.0 prototype, 22 Oct 2026

> **One line:** Paramedics capture an emergency patient's video and details. From the moment the record is sealed, no administrator, no hospital executive and no AI system can open, change or delete it alone.

---

## 1. Problem

Emergency services capture some of the most sensitive data that exists: video of a person in crisis, their home address, vitals and identity. Today that data usually lands in a hospital or vendor system where **a few people have unilateral power** over it:

| Party | Unilateral power today | Harm |
|---|---|---|
| **Administrator** (IT / DB admin, cloud host) | Reads any record, grants themselves access, restores backups | Snooping, leaks, ransomware blast radius |
| **Organisation** (hospital leadership) | Deletes or edits records after an incident | Evidence destroyed, malpractice covered up |
| **AI system** (triage / analytics model) | Bulk-reads footage "for training", or makes the triage call | Privacy breach, unaccountable automated decisions |

Patients, the people the data is about, have no say and no visibility.

## 2. Solution overview

MedQuorum is a web app with four parts:

1. **Dispatch & capture (paramedic):** take a call, see a route (simulated), record the patient on scene, get an on-device AI triage suggestion (simulated), then **encrypt on the device and seal**.
2. **Multi-party access (doctor):** a doctor must open an *access request*. The record's key is released only when a **quorum of independent, Tide-authenticated people** approves. The quorum depends on the situation (patient conscious, unconscious, nobody reachable).
3. **Governance:** who is a doctor, compliance officer or admin is decided in TideCloak, where **every role change needs a quorum of admins (QEA)**.
4. **Accountability:** a hash-chained audit log, integrity seals on every record, patient notifications, and a patient-facing view of who touched their data.

## 3. Actors and roles

All roles are **TideCloak realm roles** in realm `medquorum`, carried in a token signed by TideCloak and verified on every API call.

| Demo account | Realm role | Also `tide-realm-admin`? | Represents |
|---|---|---|---|
| `admin` | `it_admin` | Yes (first admin, created by setup) | **Administrator** |
| `director` | `hospital_director` | Yes | **Organisation** |
| `compliance` | `compliance_officer` | Yes | Independent oversight |
| `paramedic` | `paramedic` | | Data capturer |
| `drlee` | `doctor` | | Treating clinician |
| `patient1` | `patient` | | Data subject / owner |
| `nok1` | `next_of_kin` | | Proxy for an unconscious patient |
| `ai-triage-local` | *(no identity)* | | **AI system** (service, simulated) |

Default roles (every user): `_tide_vault.selfencrypt`, `_tide_vault.selfdecrypt`, `_tide_message.*`, `appUser`.

With 3 `tide-realm-admin` holders, TideCloak's QEA threshold is `max(1, floor(0.7 × 3)) = 2`.

## 4. Trust model: who can do what alone

| Action | Who could do it alone *before* | Who must agree in MedQuorum | Enforced by |
|---|---|---|---|
| Log in as a user | Whoever holds the password DB | The user (Tide BYOiD; no password DB in MedQuorum) | **TideCloak (real)** |
| Become a doctor or admin | Any admin | 2 of 3 realm admins (QEA change request) | **TideCloak QEA (real)** |
| Read a patient's personal vault | DB admin | Only the patient's own Tide session | **Tide E2EE (real)** |
| Create a case record | Anyone with DB access | A Tide-verified `paramedic` | TideCloak token + app |
| Open a sealed case (normal) | Admin / org | Treating doctor **+ patient** | App-layer quorum on Tide identities |
| Open a sealed case (unconscious) | Admin / org | Treating doctor **+ registered next of kin** | App-layer quorum |
| Open a sealed case (break-glass) | Admin / org | Doctor **+ compliance officer + hospital director**; 30 min; patient notified | App-layer quorum |
| Delete a record | Org / admin | Proposer **+ compliance officer + patient** → crypto-shred | App-layer quorum |
| Edit a record silently | DB admin | Impossible to do undetected (sealed SHA-256 + AES-GCM auth tag) | App-layer integrity |
| Rewrite history | DB admin | Impossible to do undetected (hash-chained audit) | App-layer integrity |
| Make the triage decision | AI | A doctor with an active grant confirms or overrides | App-layer |
| Bulk-read recordings | AI / analytics | Never: AI has no Tide identity or grant | App-layer |

## 5. Architecture

```
 Paramedic browser                  MedQuorum server (Next.js)              TideCloak (Docker, :8080)
 ─────────────────                  ──────────────────────────              ────────────────────────
 Tide login ───────────────────────────────────────────────────────────────▶ Tide IdP / enclave
 webcam ▶ AES-256-GCM (WebCrypto)                                            realm 'medquorum'
 AI triage (local, SIMULATED)                                                roles + QEA governance
 seal ──── ciphertext + case key ──▶ /api/cases                              ▲
                                     │  verifyTideCloakToken ────────────────┘ (signature, iss, azp, exp)
                                     ├─ data/blobs/<case>.json  (ciphertext only)
                                     ├─ data/krs/<case>.key     (Key Release Service, SIMULATED escrow)
                                     ├─ data/db.json            (metadata, requests, audit chain)
 Doctor browser                      │
 request ─────────────────────────▶ /api/cases/:id/requests
 approvers (patient/NoK/CO/dir) ──▶ /api/requests/:id/approve   (quorum engine)
 open ────────────────────────────▶ /api/cases/:id/key  ── only if quorum met ─▶ key
 decrypt in browser ◀────────────── /api/cases/:id/blob (ciphertext)
 Patient browser
 vault ▶ doEncrypt (Tide E2EE) ───▶ /api/vault (Tide ciphertext only) ───────▶ Tide Fabric (ORKs)
```

**Tech stack:** Next.js 16 / React 19 / TypeScript, `@tidecloak/nextjs` 0.14 (provider, `useTideCloak`, `doEncrypt`/`doDecrypt`, `verifyTideCloakToken`), TideCloak dev server `tideorg/tidecloak-dev` in Docker, JSON-file storage, WebCrypto AES-256-GCM.

## 6. How TideCloak solves each part of the problem

| Problem | Without TideCloak | With TideCloak |
|---|---|---|
| Identity can be forged or reset by admins | Admin resets a password and becomes the doctor | **Tide BYOiD**: the user's credentials are verified by the decentralised Tide Fabric; MedQuorum stores no passwords |
| Admin grants himself access | One DB update or console click | **Quorum-Enforced Authorization**: role grants become change requests that need 2 of 3 admins, signed by threshold signatures (no single key) |
| Approvals could be faked in the app DB | Insert a row "patient approved" | Every approval is bound to a **TideCloak-signed token** (`sub`, `preferred_username`, roles) that the server verifies with the realm's keys |
| Sensitive fields readable by whoever holds the key | Encryption key lives on the server | **Tide E2EE** (`doEncrypt` / `doDecrypt`): the key exists only as fragments across ORK nodes; decryption is re-encrypted to the user's session. Shown live with the patient vault |
| "Who changed the rules?" | Logs editable by admins | QEA logs every proposal, vote and commit with cryptographic proofs |

**Production path for the parts done in the app layer:** wrap each case key with Tide threshold encryption under a **Forseti decryption policy** (`doEncrypt(..., decryption_policy)`; the policy contract's `ValidateApprovers` enforces the M-of-N quorum). Then the Tide Fabric, not MedQuorum's server, refuses to release the key until the quorum signs, which removes the last trusted component (our Key Release Service).

## 7. Scenarios

The **Scenarios** page in the app lists all of these with steps. Labels: **REAL** = enforced by TideCloak / Tide Fabric · **APP** = enforced by the MedQuorum server using TideCloak-verified identities · **SIM** = simulated for the prototype.

| # | Scenario | Party | Enforcement | Expected result |
|---|---|---|---|---|
| S1 | Sign in with Tide; dashboard shows server-verified identity | All | REAL | Only valid TideCloak tokens are accepted |
| S2 | Paramedic dispatch + simulated route | Clinical | REAL + SIM | Paramedic role required; address never sent to a map API |
| S3 | Record on scene, encrypt on device, seal | Clinical | APP | Server stores ciphertext + SHA-256 seal only; paramedic can't re-open |
| S4 | On-device AI suggests, doctor confirms or overrides | AI system | SIM + APP | AI advisory only; human decision recorded |
| S5 | Normal access: doctor + patient | Patient | APP + REAL | Denied until the patient approves; 60-min window; self-approval rejected |
| S6 | Unconscious: doctor + next of kin | Patient | APP + REAL | Only the registered NoK account can fill the slot |
| S7 | Break-glass: doctor + compliance + director | Clinical | APP + REAL | 3 people, 30 min, patient and NoK notified |
| S8 | Admin tries to open a record / self-grant break-glass | Administrator | APP + REAL | 403 DENIED, logged; raw DB shows ciphertext |
| S9 | Admin tries to grant himself `doctor` (in-app **Governance** page or Tide console) | Administrator | **REAL** | TideCloak answers 202 and parks a change request; his own approval = 1/2; applied only after a 2nd admin approves |
| S10 | Director deletes a record; insider edits stored file | Organisation | APP | Delete parked (needs compliance + patient), then crypto-shred; tamper detected by integrity check |
| S11 | AI service bulk-reads recordings | AI system | SIM + APP | Every attempt DENIED and logged |
| S12 | Insider rewrites an audit entry | Organisation | APP | Hash chain flags the exact entry |
| S13 | Patient's personal vault with Tide E2EE | Patient | **REAL** | Server and admin see only Tide ciphertext |

## 8. API (all require a TideCloak bearer token)

| Method & path | Who | Purpose |
|---|---|---|
| `GET/POST /api/me` | any | Server-verified identity; sign-in audit |
| `GET /api/cases` · `POST /api/cases` | any / `paramedic` | List metadata / seal a new encrypted case |
| `GET /api/cases/:id` | any | Metadata + requests + my grant |
| `GET /api/cases/:id/blob` | any | Ciphertext (useless without key) |
| `GET /api/cases/:id/key` | `doctor` + quorum | **Key release**, the only path to plaintext |
| `POST /api/cases/:id/requests` | `doctor` | Open consent / proxy / break-glass request |
| `POST /api/requests/:id/approve` · `/deny` | eligible approver | Fill a slot / refuse |
| `POST /api/cases/:id/ai-decision` | `doctor` + grant | Confirm or override AI |
| `GET /api/cases/:id/verify` | any | Recompute hash against the seal |
| `POST /api/cases/:id/delete-request` | `hospital_director`, `it_admin` | Propose deletion (never executes alone) |
| `GET /api/audit` | any (scoped) | Audit entries + chain verification |
| `GET/PUT /api/vault` | owner | Tide-encrypted personal vault |
| `GET /api/admin/inspect` · `POST /api/simulate` | `it_admin`, `compliance_officer` | Raw DB view; threat simulator |
| `GET /api/governance` · `POST /api/governance/assign` · `/approve` | admins | Pass-through to TideCloak admin REST with the **caller's** token: users, role grants (→ 202 change request), QEA approvals |

**Page protection:** `proxy.ts` uses the SDK's `createTideCloakProxy` to verify the `kcToken` cookie (signature, issuer, expiry, role) before serving `/paramedic`, `/cases`, `/admin` and `/governance`.

**Approval rules** (`lib/server/policy.ts`): every slot must be filled by a distinct user; the requester can't approve; the user must hold the slot's role; pinned slots (patient, NoK) accept only that username; pending requests expire after 30 min; grants expire after 60 min (consent/proxy) or 30 min (break-glass).

## 9. Data model (what is stored, and in what form)

| Data | Stored as | Who can read the plaintext |
|---|---|---|
| Patient name, address, phone, vitals, notes, AI output | AES-256-GCM ciphertext (`data/blobs`) | Doctor with an active quorum grant (in their browser only) |
| Scene video | AES-256-GCM ciphertext | Same |
| Case key | Wrapped under the KRS master key (`data/krs`), **simulated** | Released only via `/key` after quorum |
| Personal vault | Tide E2EE ciphertext | Only the patient's Tide session |
| Case metadata (ids, usernames, timestamps, AI priority label) | Plaintext | All authenticated staff |
| Audit log | Plaintext, hash-chained | Scoped by role; integrity verifiable by all |

## 10. Mocked or simulated functionality (declared, as the submission rules require)

| Item | Status | Notes |
|---|---|---|
| AI triage | **Simulated** | Canned output from `lib/client/ai.ts`; represents an organisation-owned on-device model. No external AI API |
| Route map & ETA | **Simulated** | Static SVG; avoids sending the address to third-party map APIs |
| Dispatch calls | **Simulated** | Two canned incidents |
| Key Release Service | **Simulated stand-in** | App-held escrow. Production: Tide threshold encryption + Forseti policy |
| Multi-party access quorum | **App-layer** | Real logic on TideCloak-verified identities; production moves it into a Forseti contract |
| Threat simulator | **Simulated attacks** | The system's responses (denials, alerts, chain breaks) are real |
| Mock auth mode | Dev only | `npm run dev:mock`; red banner; not used for the demo |
| **Real:** Tide login, token verification, realm roles, QEA role governance, Tide E2EE vault | **Real** | Running against a local TideCloak dev server |

## 10b. Event note: Tide licence failure and Tideless fallback

During the event, `setUpTideRealm` failed every time with `TIDE-IDPEXT-VENDOR-KEYGEN_FAILED`. The TideCloak log shows `Midgard.FinalizeWallet: 500 Internal Server Error` from Tide's licensing service. The prototype therefore supports TideCloak's **Tideless QEA mode** (`setup-tideless.ps1`): a non-Tide realm where TideCloak still issues and signs tokens and enforces quorum on role changes, but without Tide BYOiD login or Tide E2EE. Once a licence works, `setup-tidecloak.ps1` provisions the full Tide realm with no code changes.

## 11. Limitations & future work

1. Move key escrow from the app server into **Tide Forseti** decryption policies, so even MedQuorum's operator can't release a key.
2. Real dispatch integration (CAD) and an on-device vision model (e.g. ONNX in the browser) behind the same "suggest-only" rule.
3. Push notifications to patient and NoK by SMS; pre-registered consent preferences read from the Tide vault.
4. Replace the JSON store with a database plus WORM (write-once) audit storage.
5. PDPA 2010 (Malaysia) alignment: consent records, retention schedule, data-subject access via the patient view.

## 12. Evaluation criteria mapping

| Criterion | Weight | Where it's shown |
|---|---|---|
| Vision & originality | 25% | Patient-centred, situational quorum (consent / proxy / break-glass) for emergency footage |
| Trust constraint insight | 20% | Section 4 table: every unilateral power removed, across all three named parties |
| Value & impact | 20% | Faster, safer care with footage, without creating a honeypot; patients see every access |
| Why TideCloak matters | 20% | Section 6; S1, S9, S13 run on real TideCloak; Forseti production path |
| Prototype & storytelling | 15% | 13 runnable scenarios, labelled REAL / APP / SIM, plus a 2-minute demo script in README |
