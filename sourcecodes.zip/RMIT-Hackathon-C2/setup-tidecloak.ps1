# MedQuorum - one-shot TideCloak setup for Windows (PowerShell)
# Run from this folder:   powershell -ExecutionPolicy Bypass -File .\setup-tidecloak.ps1
# Safe to re-run: every step checks what is already done.

$ErrorActionPreference = "Continue"
Set-Location $PSScriptRoot
$AppDir = Join-Path $PSScriptRoot "app"

function Step($msg) { Write-Host "`n=== $msg ===" -ForegroundColor Cyan }
function Ok($msg)   { Write-Host "  [OK] $msg" -ForegroundColor Green }
function Warn($msg) { Write-Host "  [!!] $msg" -ForegroundColor Yellow }

# ---------------------------------------------------------------- 1. Docker
Step "1/5 Docker Desktop"
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    Warn "Docker is not installed. Installing Docker Desktop with winget..."
    Warn "Click YES on the Windows admin prompt when it appears."
    winget install -e --id Docker.DockerDesktop --accept-package-agreements --accept-source-agreements
    Write-Host ""
    Warn "Docker Desktop is installed. Now:"
    Warn "  1. Restart Windows if the installer asks (it may enable WSL 2)."
    Warn "  2. Open 'Docker Desktop' from the Start menu, accept the terms, skip sign-in."
    Warn "  3. Wait until the bottom-left says 'Engine running'."
    Warn "  4. Open a NEW PowerShell window and run this script again."
    exit 0
}
docker info *> $null
if ($LASTEXITCODE -ne 0) {
    Warn "Docker is installed but the engine is not running."
    Warn "Open Docker Desktop, wait for 'Engine running', then re-run this script."
    exit 1
}
Ok "Docker engine is running"

# ---------------------------------------------------------------- 2. Node.js
Step "2/5 Node.js (needs 20.9 or later)"
$nodeOk = $false
if (Get-Command node -ErrorAction SilentlyContinue) {
    $v = (node -v).TrimStart("v").Split(".")
    if ([int]$v[0] -gt 20 -or ([int]$v[0] -eq 20 -and [int]$v[1] -ge 9)) { $nodeOk = $true }
}
if (-not $nodeOk) {
    Warn "Installing Node.js LTS with winget (click YES on the admin prompt)..."
    winget install -e --id OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements
    Warn "Node.js installed. Open a NEW PowerShell window and run this script again."
    exit 0
}
Ok "Node.js $(node -v)"

# ---------------------------------------------------------------- 3. TideCloak container
Step "3/5 TideCloak dev server (tideorg/tidecloak-dev)"
$exists = docker ps -a --filter "name=^mytidecloak$" --format "{{.Names}}"
if (-not $exists) {
    docker run --name mytidecloak -d `
        -p 8080:8080 `
        -e KC_BOOTSTRAP_ADMIN_USERNAME=admin `
        -e KC_BOOTSTRAP_ADMIN_PASSWORD=password `
        tideorg/tidecloak-dev:latest
} else {
    docker start mytidecloak *> $null
}
Write-Host "  Waiting for TideCloak on http://localhost:8080 ..."
$up = $false
for ($i = 0; $i -lt 90; $i++) {
    try {
        $r = Invoke-WebRequest -UseBasicParsing -Uri "http://localhost:8080/realms/master" -TimeoutSec 3
        if ($r.StatusCode -eq 200) { $up = $true; break }
    } catch { }
    Start-Sleep -Seconds 3
}
if (-not $up) { Warn "TideCloak did not answer. Check: docker logs mytidecloak"; exit 1 }
Ok "TideCloak is up (admin console: http://localhost:8080  user: admin / password)"

# ---------------------------------------------------------------- 4. Realm + Tide enrolment
Step "4/5 Provision realm 'medquorum' (roles, Tide IdP, licence, QEA governance)"
$cfg = Join-Path $AppDir "tidecloak.json"
$provisioned = (Test-Path $cfg) -and ((Get-Content $cfg -Raw).Trim().Length -gt 5)
if ($provisioned) {
    Ok "app\tidecloak.json already exists - realm was provisioned earlier"
} else {
    $email = Read-Host "  Email for the Tide developer licence (use a real address you can read)"
    Warn "A link will be printed below: 'ACTION REQUIRED: Open this URL and complete Tide enrollment'."
    Warn "Open it in your browser, create the Tide account for the IT ADMIN user, and leave this window running."

    # Removes a half-provisioned 'medquorum' realm left by a failed attempt, so the next attempt starts clean.
    function Remove-HalfRealm {
        try {
            $tok = (Invoke-RestMethod -Method Post -Uri "http://localhost:8080/realms/master/protocol/openid-connect/token" `
                -Body @{ grant_type = "password"; client_id = "admin-cli"; username = "admin"; password = "password" }).access_token
            Invoke-RestMethod -Method Delete -Uri "http://localhost:8080/admin/realms/medquorum" -Headers @{ Authorization = "Bearer $tok" } | Out-Null
            Warn "Removed half-provisioned realm 'medquorum'."
        } catch { }
    }

    $ok = $false
    for ($attempt = 1; $attempt -le 3 -and -not $ok; $attempt++) {
        Remove-HalfRealm
        Write-Host "  Provisioning attempt $attempt of 3..."
        docker run --rm -it --network container:mytidecloak `
            -v "${AppDir}:/app" -w /app `
            -e NEW_REALM_NAME=medquorum -e CLIENT_NAME=medquorum-app `
            -e SUBSCRIPTION_EMAIL="$email" `
            alpine:3.20 sh -c "apk add --no-cache bash curl jq sed coreutils >/dev/null && bash init/tcinit.sh"
        if ($LASTEXITCODE -eq 0) { $ok = $true }
        elseif ($attempt -lt 3) { Warn "Attempt $attempt failed (often a temporary Tide licensing/network hiccup). Retrying in 20s..."; Start-Sleep -Seconds 20 }
    }
    if (-not $ok) {
        Remove-HalfRealm
        Warn "Realm provisioning failed 3 times - copy the output above and send it to Claude."
        exit 1
    }
    Ok "Realm provisioned, adapter written to app\tidecloak.json"
}

# ---------------------------------------------------------------- 5. Verify connection
Step "5/5 Verify the app can reach TideCloak"
$tc = Get-Content $cfg -Raw | ConvertFrom-Json
$wellKnown = "$($tc.'auth-server-url'.TrimEnd('/'))/realms/$($tc.realm)/.well-known/openid-configuration"
try {
    $wk = Invoke-RestMethod -Uri $wellKnown -TimeoutSec 5
    Ok "Realm '$($tc.realm)' reachable. Issuer: $($wk.issuer)"
    Ok "Client: $($tc.resource)"
} catch {
    Warn "Could not reach $wellKnown"; exit 1
}
Write-Host "`nAll set. Next: cd app ; npm install ; npm run dev   ->  http://localhost:3000" -ForegroundColor Green
